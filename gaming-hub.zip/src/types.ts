/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface SystemRequirementsDetail {
  os: string;
  cpu: string;
  ram: string;
  gpu: string;
  storage: string;
}

export interface SystemRequirements {
  minimum: SystemRequirementsDetail;
  recommended: SystemRequirementsDetail;
}

export interface GameComment {
  id: string;
  username: string;
  avatar: string;
  comment: string;
  date: string;
}

export interface Game {
  id: string;
  title: string;
  description: string;
  longDescription?: string;
  image: string;
  banner?: string;
  platform: 'Steam' | 'Epic Games' | 'Ubisoft' | 'EA' | 'GOG' | 'Microsoft Store' | 'Battle.net' | 'Amazon Prime Gaming' | string;
  originalPrice: number;
  currentPrice: number;
  discountPercentage: number;
  timer: string; // ISO Date or formatted string
  genre: string;
  rating: number;
  systemRequirements?: SystemRequirements;
  screenshots?: string[];
  comments?: GameComment[];
  externalStoreUrl?: string;
}

export interface SteamAccount {
  id: string;
  title: string;
  includedGames: string[];
  dateAdded: string;
  isAvailable: boolean;
  email: string;
  password: string;
  notes?: string;
  image: string;
}

export interface CommunityComment {
  id: string;
  username: string;
  avatar: string;
  content: string;
  date: string;
}

export interface Post {
  id: string;
  username: string;
  avatar: string;
  title?: string;
  content: string;
  date: string;
  likes: number;
  dislikes: number;
  likedByUser?: boolean;
  dislikedByUser?: boolean;
  comments: CommunityComment[];
  image?: string;
}

export interface MemeTemplate {
  id: string;
  name: string;
  url: string;
  description: string;
}
