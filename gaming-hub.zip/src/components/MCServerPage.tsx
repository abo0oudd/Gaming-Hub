/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { 
  Copy, 
  Check, 
  Play, 
  ExternalLink, 
  Server, 
  Wifi, 
  Info, 
  Cpu,
  Monitor,
  Smartphone
} from "lucide-react";

export default function MCServerPage() {
  const [copiedJava, setCopiedJava] = useState(false);
  const [copiedBedrock, setCopiedBedrock] = useState(false);
  const [activeVideo, setActiveVideo] = useState<string | null>(null);

  const handleCopy = (text: string, type: "java" | "bedrock") => {
    navigator.clipboard.writeText(text);
    if (type === "java") {
      setCopiedJava(true);
      setTimeout(() => setCopiedJava(false), 2500);
    } else {
      setCopiedBedrock(true);
      setTimeout(() => setCopiedBedrock(false), 2500);
    }
  };

  const videoList = [
    {
      id: "v1",
      title: "شرح كيف تلعب ماينكرافت الجوال مع حاسب في سيرفر Vila_OSK واللعب تيم",
      duration: "08:52",
      youtubeId: "iIdVjeKKpwk",
      views: "شرح شامل",
      author: "Vila_OSK",
      thumbnail: "https://img.youtube.com/vi/iIdVjeKKpwk/hqdefault.jpg"
    },
    {
      id: "v2",
      title: "افضل طريقه لتصل بورت سرفر vil_OSK والعب مع كل الاجهزه",
      duration: "06:14",
      youtubeId: "H6WxRIZGFxI",
      views: "شرح الاتصال",
      author: "Vila_OSK",
      thumbnail: "https://img.youtube.com/vi/H6WxRIZGFxI/hqdefault.jpg"
    }
  ];

  return (
    <div className="w-full min-h-screen text-slate-100 font-[Tajawal] relative overflow-hidden" id="mcservercleanpro">
      
      {/* Dynamic Ambient Background Aura */}
      <div className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-emerald-500/10 rounded-full blur-[150px] pointer-events-none"></div>
      <div className="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] bg-blue-600/10 rounded-full blur-[150px] pointer-events-none"></div>

      {/* Floating Particles Overlay */}
      <div className="absolute inset-0 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:24px_24px] opacity-10 pointer-events-none"></div>

      {/* Hero Header Space */}
      <div className="relative pt-24 pb-12 px-4 text-center z-10 space-y-6">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-bold font-[Cairo]">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
          <span>بوابة الاتصال بالخادم السحابي آمنة ونشطة</span>
        </div>
        
        <h1 className="text-4xl sm:text-6xl font-black font-[Changa] tracking-tight text-white select-none">
          سيرفر <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-400 to-sky-400">جيمينج كرافت</span>
        </h1>
        <p className="text-sm sm:text-base text-slate-400 font-[Tajawal] max-w-xl mx-auto leading-relaxed">
          عالم البقاء الأسطوري واللعب التنافسي المطور. نوفر لك خادماً سحابياً متكاملاً فائق السرعة وبدون أي لاق.
        </p>
      </div>

      {/* ================= IP & PORT SECTION ================= */}
      <section className="max-w-4xl mx-auto px-4 pb-16 relative z-10" id="mc-connection-ips">
        <div className="bg-slate-900/40 backdrop-blur-md rounded-3xl p-6 sm:p-8 border border-slate-800/80 shadow-[0_8px_32px_rgba(0,0,0,0.4)]">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
            <div className="flex items-center gap-2">
              <Server className="w-5 h-5 text-emerald-400" />
              <h2 className="text-lg font-bold text-white font-[Changa]">معلومات الاتصال بالسيرفر</h2>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-slate-400 font-semibold">
              <Wifi className="w-4 h-4 text-emerald-400" />
              <span>معدل اتصال ممتاز</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Java Edition */}
            <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-5 hover:border-emerald-500/30 transition-all duration-300 relative group overflow-hidden">
              <div className="flex items-center justify-between mb-4">
                <span className="text-[10px] uppercase tracking-wider font-bold text-emerald-400 font-mono bg-emerald-500/10 px-2 py-0.5 rounded-md flex items-center gap-1">
                  <Monitor className="w-3 h-3" />
                  <span>Java Edition (PC)</span>
                </span>
                <span className="text-xs text-slate-400 font-bold font-[Cairo]">إصدار 1.20+</span>
              </div>
              
              <div className="text-right mb-5">
                <div className="text-[10px] text-slate-500 font-bold">عنوان السيرفر (IP)</div>
                <div className="text-base font-bold font-mono text-white tracking-wide mt-1 select-all">mc.gaminghub.pro</div>
              </div>

              <button
                onClick={() => handleCopy("mc.gaminghub.pro", "java")}
                className={`w-full py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all duration-200 ${
                  copiedJava 
                    ? "bg-emerald-500 text-slate-900 shadow-[0_0_15px_rgba(16,185,129,0.3)]" 
                    : "bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800"
                }`}
              >
                {copiedJava ? (
                  <>
                    <Check className="w-4 h-4 stroke-[3px]" />
                    <span>تم نَسخ العنوان بنجاح!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4" />
                    <span>نسخ عنوان الـ IP</span>
                  </>
                )}
              </button>
            </div>

            {/* Bedrock Edition */}
            <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-5 hover:border-sky-500/30 transition-all duration-300 relative group overflow-hidden">
              <div className="flex items-center justify-between mb-4">
                <span className="text-[10px] uppercase tracking-wider font-bold text-sky-400 font-mono bg-sky-500/10 px-2 py-0.5 rounded-md flex items-center gap-1">
                  <Smartphone className="w-3 h-3" />
                  <span>Bedrock (الجوال)</span>
                </span>
                <span className="text-xs text-slate-400 font-bold font-[Cairo]">بورت افتراضي</span>
              </div>
              
              <div className="text-right mb-5 grid grid-cols-2 gap-2">
                <div>
                  <div className="text-[10px] text-slate-500 font-bold">الخادم (Address)</div>
                  <div className="text-sm font-bold font-mono text-white tracking-wide mt-1 select-all">pe.gaminghub.pro</div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-500 font-bold">المنفذ (Port)</div>
                  <div className="text-sm font-bold font-mono text-sky-400 tracking-wide mt-1 select-all">19132</div>
                </div>
              </div>

              <button
                onClick={() => handleCopy("pe.gaminghub.pro", "bedrock")}
                className={`w-full py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all duration-200 ${
                  copiedBedrock 
                    ? "bg-sky-500 text-slate-900 shadow-[0_0_15px_rgba(14,165,233,0.3)]" 
                    : "bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800"
                }`}
              >
                {copiedBedrock ? (
                  <>
                    <Check className="w-4 h-4 stroke-[3px]" />
                    <span>تم نَسخ الإعدادات بنجاح!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4" />
                    <span>نسخ البورت والعنوان</span>
                  </>
                )}
              </button>
            </div>
          </div>

          <div className="mt-6 p-4 rounded-xl bg-slate-950/40 border border-slate-800 flex items-center gap-3 text-right">
            <Info className="w-5 h-5 text-indigo-400 flex-shrink-0" />
            <p className="text-xs text-slate-400 leading-relaxed">
              السيرفر متوافق بالكامل بين الحاسب وعشاق الجوال في نفس الخريطة ويدعم الإصدارات الحديثة.
            </p>
          </div>
        </div>
      </section>

      {/* ================= VIDEOS & TUTORIALS SECTION ================= */}
      <section className="max-w-4xl mx-auto px-4 pb-24 relative z-10" id="mc-tutorials-videos">
        <div className="text-center mb-10">
          <h2 className="text-2xl font-black font-[Changa] text-white">فيديوهات وشروحات السيرفر</h2>
          <p className="text-slate-400 text-xs sm:text-sm mt-2">شاهد الشروحات الحصرية المجهزة لتسهيل لعبك والتفوق في عالم السيرفر</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {videoList.map((vid) => (
            <div 
              key={vid.id}
              className="bg-slate-900/40 border border-slate-800/80 hover:border-slate-700 rounded-2xl overflow-hidden transition-all duration-300 group shadow-md flex flex-col"
            >
              <div className="relative aspect-video bg-slate-950 overflow-hidden">
                {activeVideo === vid.id ? (
                  <iframe
                    className="w-full h-full"
                    src={`https://www.youtube.com/embed/${vid.youtubeId}?autoplay=1`}
                    title={vid.title}
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  ></iframe>
                ) : (
                  <>
                    <img 
                      src={vid.thumbnail} 
                      alt={vid.title} 
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 filter brightness-[0.7] group-hover:brightness-90"
                    />
                    <div className="absolute inset-0 bg-slate-950/40 flex items-center justify-center group-hover:bg-slate-950/20 transition-colors">
                      <button 
                        onClick={() => setActiveVideo(vid.id)}
                        className="w-14 h-14 rounded-full bg-red-600 hover:bg-red-500 text-white flex items-center justify-center shadow-md transform group-hover:scale-110 transition-transform shadow-red-600/20"
                      >
                        <Play className="w-5 h-5 fill-white stroke-none translate-x-[2px]" />
                      </button>
                    </div>
                    <span className="absolute bottom-3 left-3 bg-slate-950/90 text-white text-[10px] font-bold px-2 py-0.5 rounded font-mono">{vid.duration}</span>
                  </>
                )}
              </div>

              <div className="p-5 text-right space-y-3 flex-grow flex flex-col justify-between">
                <div>
                  <div className="flex justify-between items-center text-[10px] text-slate-400 font-bold">
                    <span>{vid.views}</span>
                    <span className="text-indigo-400">{vid.author}</span>
                  </div>
                  <h4 className="text-sm font-bold text-white font-[Changa] mt-2 group-hover:text-amber-300 transition-colors">
                    {vid.title}
                  </h4>
                </div>
                
                <button 
                  onClick={() => setActiveVideo(activeVideo === vid.id ? null : vid.id)}
                  className="text-[11px] text-slate-400 hover:text-white flex items-center justify-end gap-1 font-bold mt-2"
                >
                  <span>{activeVideo === vid.id ? "إغلاق المشغّل" : "تشغيل الشرح بالفيديو"}</span>
                  <ExternalLink className="w-3 h-3 text-indigo-400" />
                </button>
              </div>

            </div>
          ))}
        </div>
      </section>

      {/* ================= SOCIAL MEDIA PLATFORMS SECTION ================= */}
      <section className="max-w-4xl mx-auto px-4 pb-24 relative z-10 text-center" id="owner-social-connect">
        <span className="block h-[1px] w-full bg-gradient-to-r from-transparent via-purple-500/25 to-transparent mb-12"></span>
        <div className="space-y-4 mb-8">
          <h3 className="text-xl font-bold font-[Changa] text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-200 to-purple-400">قنوات التواصل الخاصة بي</h3>
          <p className="text-slate-400 text-xs sm:text-sm max-w-md mx-auto">تابعني على حساباتي الرسمية لمتابعة كافة الشروحات والأخبار والفعاليات القادمة في السيرفر بشكل حصري</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-2xl mx-auto">
          {/* TikTok Link */}
          <a
            href="https://www.tiktok.com/@abo0oudd"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-between p-4 bg-[#030307]/50 backdrop-blur border border-purple-500/10 hover:border-purple-500/35 hover:shadow-[0_0_15px_rgba(168,85,247,0.15)] rounded-2xl group transition-all duration-300 transform hover:-translate-y-1 shadow-[0_4px_20px_rgba(0,0,0,0.3)]"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-purple-500/10 flex items-center justify-center text-purple-400 group-hover:bg-purple-500 group-hover:text-black transition-all">
                {/* TikTok custom inline SVG (precise) */}
                <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                  <path d="M12.5a6.5 6.5 0 1 1-6.5-6.5h1.5v2H7.5A4.5 4.5 0 1 0 12 12.5v-10h2a4.5 4.5 0 0 1 4.5 4.5H16.5a2.5 2.5 0 0 0-2.5-2.5h-1.5v8z"/>
                </svg>
              </div>
              <div className="text-right">
                <span className="block text-[10px] text-slate-500 font-bold">TikTok</span>
                <span className="block text-xs font-bold text-slate-300 font-mono">@abo0oudd</span>
              </div>
            </div>
            <ExternalLink className="w-4 h-4 text-slate-600 group-hover:text-purple-400 transition-colors" />
          </a>

          {/* Instagram Link */}
          <a
            href="https://instagram.com/abo0oudd"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-between p-4 bg-[#030307]/50 backdrop-blur border border-purple-500/10 hover:border-purple-500/35 hover:shadow-[0_0_15px_rgba(244,63,94,0.15)] rounded-2xl group transition-all duration-300 transform hover:-translate-y-1 shadow-[0_4px_20px_rgba(0,0,0,0.3)]"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-pink-500/10 flex items-center justify-center text-pink-400 group-hover:bg-pink-500 group-hover:text-black transition-all">
                <svg className="w-5 h-5 fill-none stroke-current" strokeWidth="2" viewBox="0 0 24 24" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
                  <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                  <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
                </svg>
              </div>
              <div className="text-right">
                <span className="block text-[10px] text-slate-500 font-bold">Instagram</span>
                <span className="block text-xs font-bold text-slate-300 font-mono">@abo0oudd</span>
              </div>
            </div>
            <ExternalLink className="w-4 h-4 text-slate-600 group-hover:text-pink-400 transition-colors" />
          </a>

          {/* YouTube Link */}
          <a
            href="https://youtube.com/@vilaosk_0"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-between p-4 bg-[#030307]/50 backdrop-blur border border-purple-500/10 hover:border-purple-500/35 hover:shadow-[0_0_15px_rgba(239,68,68,0.15)] rounded-2xl group transition-all duration-300 transform hover:-translate-y-1 shadow-[0_4px_20px_rgba(0,0,0,0.3)]"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-red-500/10 flex items-center justify-center text-red-400 group-hover:bg-red-500 group-hover:text-black transition-all">
                <svg className="w-5 h-5 fill-none stroke-current" strokeWidth="2" viewBox="0 0 24 24" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M22.54 6.42a2.78 2.78 0 0 0-1.94-2C18.88 4 12 4 12 4s-6.88 0-8.6.46a2.78 2.78 0 0 0-1.94 2A29 29 0 0 0 1 11.75a29 29 0 0 0 .46 5.33A2.78 2.78 0 0 0 3.4 19c1.72.46 8.6.46 8.6.46s6.88 0 8.6-.46a2.78 2.78 0 0 0 1.94-2 29 29 0 0 0 .46-5.25 29 29 0 0 0-.46-5.33z"></path>
                  <polygon points="9.75 15.02 15.5 11.75 9.75 8.48 9.75 15.02"></polygon>
                </svg>
              </div>
              <div className="text-right">
                <span className="block text-[10px] text-slate-500 font-bold">YouTube</span>
                <span className="block text-xs font-bold text-slate-300 font-mono">@vilaosk_0</span>
              </div>
            </div>
            <ExternalLink className="w-4 h-4 text-slate-600 group-hover:text-red-400 transition-colors" />
          </a>
        </div>
      </section>

    </div>
  );
}
