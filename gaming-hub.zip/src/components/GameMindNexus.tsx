/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { 
  Brain, Sparkles, Cpu, Columns4, Compass, LineChart, 
  Gamepad2, Users, ArrowUpRight, Zap, RefreshCw, Copy, Check, 
  Terminal, Image as ImageIcon, Video, Code, Palette, Sliders, ShieldCheck
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface GameMindNexusProps {
  games: any[];
}

export default function GameMindNexus({ games }: GameMindNexusProps) {
  const [activeTab, setActiveTab] = useState<string>("names");
  const [copiedText, setCopiedText] = useState<string | null>(null);

  // States for Tool 1: AI Game Name Generator
  const [nameMode, setNameMode] = useState("individual");
  const [nameStyle, setNameStyle] = useState("cyberpunk");
  const [nameLang, setNameLang] = useState("mix");
  const [nameLetters, setNameLetters] = useState("");
  const [nameIsRandom, setNameIsRandom] = useState(true);
  const [generatedNames, setGeneratedNames] = useState<any[]>([]);
  const [loadingNames, setLoadingNames] = useState(false);

  // States for Tool 2: AI Avatar & Design concepts
  const [avatarStyle, setAvatarStyle] = useState("Cyberpunk Hacker");
  const [avatarType, setAvatarType] = useState("humanoid");
  const [avatarColor, setAvatarColor] = useState<string[]>(["#a855f7", "#06b6d4"]); // Purple & Cyan
  const [generatedAvatars, setGeneratedAvatars] = useState<any[]>([]);
  const [loadingAvatars, setLoadingAvatars] = useState(false);
  const [avatarCustomSeeds, setAvatarCustomSeeds] = useState<Record<number, string>>({});

  // States for Tool 3: AI Predictive suggestions
  const [similarGamesInput, setSimilarGamesInput] = useState("");
  const [selectedSpecGenres, setSelectedSpecGenres] = useState<string[]>([]);
  const [gamerMood, setGamerMood] = useState("intense battlefield sweat");
  const [gameplayPreference, setGameplayPreference] = useState("competitive");
  const [recsList, setRecsList] = useState<any[]>([]);
  const [loadingRecs, setLoadingRecs] = useState(false);

  // States for Tool 4: Settings optimizer
  const [optGameName, setOptGameName] = useState("");
  const [optCpu, setOptCpu] = useState("");
  const [optGpu, setOptGpu] = useState("");
  const [optRam, setOptRam] = useState("16 GB");
  const [optGoal, setOptGoal] = useState("fps");
  const [optimizationsResult, setOptimizationsResult] = useState<any | null>(null);
  const [loadingOptimizer, setLoadingOptimizer] = useState(false);

  // States for Tool 5: RGB Setup wall generator
  const [setupLayout, setSetupLayout] = useState("minimal-desk");
  const [primaryColor, setPrimaryColor] = useState("#a855f7"); // Purple
  const [secondaryColor, setSecondaryColor] = useState("#06b6d4"); // Cyan
  const [setupVibes, setSetupVibes] = useState("Synthwave Sunset");
  const [rgbThemeResult, setRgbThemeResult] = useState<any | null>(null);
  const [loadingRgb, setLoadingRgb] = useState(false);

  // States for Tool 6: Streamer content viral generator
  const [creatorPlatform, setCreatorPlatform] = useState("tiktok");
  const [creatorVibe, setCreatorVibe] = useState("funny glitches");
  const [creatorPreferredGame, setCreatorPreferredGame] = useState("");
  const [contentIdeas, setContentIdeas] = useState<any[]>([]);
  const [loadingContent, setLoadingContent] = useState(false);

  // States for Tool 7: Gamer personality test
  const [surveyStep, setSurveyStep] = useState(0);
  const [surveyAnswers, setSurveyAnswers] = useState<string[]>([
    "أتجاهله تماماً وأقوم بحظره فوراً للتركيز على المباراة",
    "أحلل تكتيكي وأغير استراتيجيتي وأحاول المحاولة مجدداً بهدوء",
    "القصة العميقة والغوص في العالم وتفاصيله والشخصيات",
    "أخطط بهدوء، أترقب حركة الخصم، وأحاول استغلال ميزة المفاجأة",
    "أستكشف أدق التفاصيل وأحاول فك الأسرار المخفية"
  ]);
  const [surveyResult, setSurveyResult] = useState<any | null>(null);
  const [loadingSurvey, setLoadingSurvey] = useState(false);

  // Copy helper
  const handleCopyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(text);
    setTimeout(() => setCopiedText(null), 2000);
  };

  // 1. Submit Name Generator
  const handleGenerateNames = async () => {
    setLoadingNames(true);
    setGeneratedNames([]);
    try {
      const response = await fetch("/api/ai/gaming-name", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          mode: nameMode,
          style: nameStyle,
          language: nameLang,
          letters: nameLetters,
          isRandom: nameIsRandom
        })
      });
      if (response.ok) {
        const data = await response.json();
        if (data.names) {
          setGeneratedNames(data.names);
        }
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingNames(false);
    }
  };

  // 2. Submit Avatar Designer
  const handleGenerateAvatars = async () => {
    setLoadingAvatars(true);
    setGeneratedAvatars([]);
    setAvatarCustomSeeds({});
    try {
      const response = await fetch("/api/ai/gaming-avatar", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          style: avatarStyle,
          avatarType: avatarType,
          preferredColors: avatarColor
        })
      });
      if (response.ok) {
        const data = await response.json();
        if (data.concepts) {
          setGeneratedAvatars(data.concepts);
        }
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingAvatars(false);
    }
  };

  // 3. Submit Recommendations
  const handleGenerateRecommendations = async () => {
    setLoadingRecs(true);
    setRecsList([]);
    try {
      const response = await fetch("/api/ai/games-suggest", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          favoriteGames: similarGamesInput,
          categories: selectedSpecGenres,
          mood: gamerMood,
          style: gameplayPreference
        })
      });
      if (response.ok) {
        const data = await response.json();
        if (data.recommendations) {
          setRecsList(data.recommendations);
        }
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingRecs(false);
    }
  };

  // 4. Submit FPS Optimizer
  const handleGenerateOptimizations = async () => {
    setLoadingOptimizer(true);
    setOptimizationsResult(null);
    try {
      const response = await fetch("/api/ai/fps-optimizer", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          gameName: optGameName,
          cpuName: optCpu,
          gpuName: optGpu,
          ramSize: optRam,
          targetGoal: optGoal
        })
      });
      if (response.ok) {
        const data = await response.json();
        setOptimizationsResult(data);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingOptimizer(false);
    }
  };

  // 5. Submit RGB Themes Planner
  const handleGenerateRgb = async () => {
    setLoadingRgb(true);
    setRgbThemeResult(null);
    try {
      const response = await fetch("/api/ai/rgb-themes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          setupType: setupLayout,
          primaryColor: primaryColor,
          secondaryColor: secondaryColor,
          vibes: setupVibes
        })
      });
      if (response.ok) {
        const data = await response.json();
        setRgbThemeResult(data);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingRgb(false);
    }
  };

  // 6. Submit Content ideas
  const handleGenerateContentIdeas = async () => {
    setLoadingContent(true);
    setContentIdeas([]);
    try {
      const response = await fetch("/api/ai/content-ideas", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          platform: creatorPlatform,
          contentStyle: creatorVibe,
          preferredGame: creatorPreferredGame
        })
      });
      if (response.ok) {
        const data = await response.json();
        if (data.ideas) {
          setContentIdeas(data.ideas);
        }
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingContent(false);
    }
  };

  // 7. Submit Gamer Personality test
  const handleAnalyzePersonality = async () => {
    setLoadingSurvey(true);
    setSurveyResult(null);
    try {
      const response = await fetch("/api/ai/gamer-personality", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ answers: surveyAnswers })
      });
      if (response.ok) {
        const data = await response.json();
        setSurveyResult(data);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingSurvey(false);
    }
  };

  const handleToggleGenre = (genre: string) => {
    if (selectedSpecGenres.includes(genre)) {
      setSelectedSpecGenres(selectedSpecGenres.filter(g => g !== genre));
    } else {
      setSelectedSpecGenres([...selectedSpecGenres, genre]);
    }
  };

  return (
    <div className="relative w-full min-h-screen bg-slate-950 text-white selection:bg-purple-500/30 selection:text-white px-4 sm:px-6 lg:px-8 pb-24 pt-8">
      {/* Absolute futuristic cosmic lighting */}
      <div className="absolute top-0 right-1/4 w-[40rem] h-[30rem] bg-indigo-500/5 rounded-full blur-[140px] pointer-events-none z-0"></div>
      <div className="absolute bottom-12 left-1/4 w-[35rem] h-[30rem] bg-purple-500/5 rounded-full blur-[120px] pointer-events-none z-0"></div>

      {/* Main Core Container */}
      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Futuristic Cinematic Page Header */}
        <div className="text-center mb-16 relative">
          <div className="absolute inset-x-0 -top-8 h-20 bg-gradient-to-b from-purple-500/10 via-transparent to-transparent pointer-events-none filter blur-xl"></div>
          
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2.5 px-5 py-2 rounded-full border border-purple-500/20 bg-purple-500/10 backdrop-blur-md text-[11px] font-bold text-purple-300 tracking-wider mb-5 font-[Changa] shadow-[0_0_20px_rgba(168,85,247,0.15)]"
          >
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-[ping_1.5s_infinite]"></span>
            <span className="font-mono bg-indigo-500/20 px-2 py-0.5 rounded text-[10px] text-cyan-300 border border-cyan-500/10 leading-none">AI LAB v4.0</span>
            <span>بوابة الذكاء الاصطناعي الأسرع للاعبين المحترفين</span>
          </motion.div>

          <motion.h1 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-4xl sm:text-6xl font-black font-[Changa] leading-tight text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-200 to-slate-400 mb-6 drop-shadow-[0_2px_10px_rgba(0,0,0,0.5)]"
          >
            عقل اللاعب — <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-indigo-400 to-cyan-400 font-extrabold">GameMind Nexus</span>
          </motion.h1>

          <motion.p 
            initial={{ y: 15, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-sm max-w-3xl mx-auto text-slate-400 font-[Tajawal] leading-relaxed"
          >
            ليس مجرد صفحة أدوات عادية؛ بل مختبر معزز بأقوى نماذج التنبؤ وتوليد البيانات السيبرانية. ولّد الأسماء الأسطورية، حسّن إطارات كرت الشاشة، حلل شخصيتك الرقمية وهندس إضاءة غرفتك في المتروبوليس المستقبلي.
          </motion.p>
        </div>

        {/* Cyber Interactive Sidebar Tabs & Main Stage Panel Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Cyber Sidebar Console Controller Tabs */}
          <div className="lg:col-span-3 space-y-3.5 order-2 lg:order-1">
            <div className="text-right px-2 mb-2">
              <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest block font-semibold">AI Console Modules</span>
              <p className="text-xs text-slate-400 font-[Cairo]">اختر أداة التشغيل السيبرانية:</p>
            </div>

            <div className="flex flex-col gap-2 bg-slate-900/40 border border-slate-900/60 p-2.5 rounded-2xl backdrop-blur-md relative overflow-hidden">
              <div className="absolute top-0 right-0 w-8 h-8 bg-purple-500/5 rounded-full blur-md"></div>
              
              <button 
                onClick={() => { setActiveTab("names"); }}
                className={`w-full flex items-center justify-between px-3.5 py-3 rounded-xl transition duration-200 text-right ${
                  activeTab === "names" 
                    ? "bg-gradient-to-r from-purple-600/20 to-indigo-500/10 border border-purple-500/30 text-purple-200 shadow-[0_0_15px_rgba(168,85,247,0.1)]" 
                    : "text-slate-400 hover:text-slate-200 hover:bg-slate-900/50 border border-transparent"
                }`}
              >
                <div className="flex items-center gap-3">
                  <Terminal className="w-5 h-5 text-purple-400 stroke-[2px]" />
                  <div className="text-right">
                    <span className="text-xs font-bold block font-[Cairo]">مولد الأسماء الذكي</span>
                    <span className="text-[9px] font-mono text-slate-500">GAMING ALIASES</span>
                  </div>
                </div>
                <Zap className={`w-3.5 h-3.5 transition-all ${activeTab === "names" ? "text-cyan-400 scale-110" : "text-slate-600"}`} />
              </button>

              <button 
                onClick={() => { setActiveTab("avatars"); }}
                className={`w-full flex items-center justify-between px-3.5 py-3 rounded-xl transition duration-200 text-right ${
                  activeTab === "avatars" 
                    ? "bg-gradient-to-r from-purple-600/20 to-indigo-500/10 border border-purple-500/30 text-purple-200 shadow-[0_0_15px_rgba(168,85,247,0.1)]" 
                    : "text-slate-400 hover:text-slate-200 hover:bg-slate-900/50 border border-transparent"
                }`}
              >
                <div className="flex items-center gap-3">
                  <Palette className="w-5 h-5 text-cyan-400 stroke-[2px]" />
                  <div className="text-right">
                    <span className="text-xs font-bold block font-[Cairo]">مصمم الأفاتار والهويات</span>
                    <span className="text-[9px] font-mono text-slate-500">INDENTITY VISUALIZER</span>
                  </div>
                </div>
                <Palette className={`w-3.5 h-3.5 transition-all ${activeTab === "avatars" ? "text-cyan-400 scale-110" : "text-slate-600"}`} />
              </button>

              <button 
                onClick={() => { setActiveTab("recs"); }}
                className={`w-full flex items-center justify-between px-3.5 py-3 rounded-xl transition duration-200 text-right ${
                  activeTab === "recs" 
                    ? "bg-gradient-to-r from-purple-600/20 to-indigo-500/10 border border-purple-500/30 text-purple-200 shadow-[0_0_15px_rgba(168,85,247,0.1)]" 
                    : "text-slate-400 hover:text-slate-200 hover:bg-slate-900/50 border border-transparent"
                }`}
              >
                <div className="flex items-center gap-3">
                  <Compass className="w-5 h-5 text-indigo-400 stroke-[2px]" />
                  <div className="text-right">
                    <span className="text-xs font-bold block font-[Cairo]">عرّاف الألعاب التنبؤي</span>
                    <span className="text-[9px] font-mono text-slate-500">SMART GAME DIALING</span>
                  </div>
                </div>
                <Compass className={`w-3.5 h-3.5 transition-all ${activeTab === "recs" ? "text-cyan-400 scale-110" : "text-slate-600"}`} />
              </button>

              <button 
                onClick={() => { setActiveTab("fps"); }}
                className={`w-full flex items-center justify-between px-3.5 py-3 rounded-xl transition duration-200 text-right ${
                  activeTab === "fps" 
                    ? "bg-gradient-to-r from-purple-600/20 to-indigo-500/10 border border-purple-500/30 text-purple-200 shadow-[0_0_15px_rgba(168,85,247,0.1)]" 
                    : "text-slate-400 hover:text-slate-200 hover:bg-slate-900/50 border border-transparent"
                }`}
              >
                <div className="flex items-center gap-3">
                  <Sliders className="w-5 h-5 text-yellow-400 stroke-[2px]" />
                  <div className="text-right">
                    <span className="text-xs font-bold block font-[Cairo]">مسرع الإطارات (FPS)</span>
                    <span className="text-[9px] font-mono text-slate-500">HARDWARE DIOGNOSTICS</span>
                  </div>
                </div>
                <Sliders className={`w-3.5 h-3.5 transition-all ${activeTab === "fps" ? "text-cyan-400 scale-110" : "text-slate-600"}`} />
              </button>

              <button 
                onClick={() => { setActiveTab("rgb"); }}
                className={`w-full flex items-center justify-between px-3.5 py-3 rounded-xl transition duration-200 text-right ${
                  activeTab === "rgb" 
                    ? "bg-gradient-to-r from-purple-600/20 to-indigo-500/10 border border-purple-500/30 text-purple-200 shadow-[0_0_15px_rgba(168,85,247,0.1)]" 
                    : "text-slate-400 hover:text-slate-200 hover:bg-slate-900/50 border border-transparent"
                }`}
              >
                <div className="flex items-center gap-3">
                  <Columns4 className="w-5 h-5 text-pink-400 stroke-[2px]" />
                  <div className="text-right">
                    <span className="text-xs font-bold block font-[Cairo]">هندسة الغرف والخلفيات</span>
                    <span className="text-[9px] font-mono text-slate-500">WORKSPACE RGB DESIGN</span>
                  </div>
                </div>
                <Columns4 className={`w-3.5 h-3.5 transition-all ${activeTab === "rgb" ? "text-cyan-400 scale-110" : "text-slate-600"}`} />
              </button>

              <button 
                onClick={() => { setActiveTab("creator"); }}
                className={`w-full flex items-center justify-between px-3.5 py-3 rounded-xl transition duration-200 text-right ${
                  activeTab === "creator" 
                    ? "bg-gradient-to-r from-purple-600/20 to-indigo-500/10 border border-purple-500/30 text-purple-200 shadow-[0_0_15px_rgba(168,85,247,0.1)]" 
                    : "text-slate-400 hover:text-slate-200 hover:bg-slate-900/50 border border-transparent"
                }`}
              >
                <div className="flex items-center gap-3">
                  <Video className="w-5 h-5 text-blue-400 stroke-[2px]" />
                  <div className="text-right">
                    <span className="text-xs font-bold block font-[Cairo]">خطاف صُنّاع المحتوى</span>
                    <span className="text-[9px] font-mono text-slate-500">STREAM VIRAL SCRIPTS</span>
                  </div>
                </div>
                <Video className={`w-3.5 h-3.5 transition-all ${activeTab === "creator" ? "text-cyan-400 scale-110" : "text-slate-600"}`} />
              </button>

              <button 
                onClick={() => { setActiveTab("personality"); }}
                className={`w-full flex items-center justify-between px-3.5 py-3 rounded-xl transition duration-200 text-right ${
                  activeTab === "personality" 
                    ? "bg-gradient-to-r from-purple-600/20 to-indigo-500/10 border border-purple-500/30 text-purple-200 shadow-[0_0_15px_rgba(168,85,247,0.1)]" 
                    : "text-slate-400 hover:text-slate-200 hover:bg-slate-900/50 border border-transparent"
                }`}
              >
                <div className="flex items-center gap-3">
                  <Brain className="w-5 h-5 text-emerald-400 stroke-[2px]" />
                  <div className="text-right">
                    <span className="text-xs font-bold block font-[Cairo]">محلل شخصية اللاعب</span>
                    <span className="text-[9px] font-mono text-slate-500">GAMER ANALYSIS TEST</span>
                  </div>
                </div>
                <Brain className={`w-3.5 h-3.5 transition-all ${activeTab === "personality" ? "text-cyan-400 scale-110" : "text-slate-600"}`} />
              </button>
            </div>

            {/* Quick Server-Side Status Panel */}
            <div className="p-4 bg-slate-900/10 border border-slate-900/60 rounded-2xl backdrop-blur-sm space-y-2 text-right">
              <div className="flex items-center justify-between flex-row-reverse text-[10px]">
                <span className="text-slate-400 font-[Cairo] font-bold">بوابة نماذج الاستدلال</span>
                <span className="flex items-center gap-1 font-mono text-emerald-400 font-bold bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/10">
                  <span className="w-1 h-1 rounded-full bg-emerald-400 animate-pulse"></span>
                  Active
                </span>
              </div>
              <p className="text-[10px] text-slate-500 font-mono">
                System node: secure-express-clun-run<br />
                Primary unit: @google/genai (3.5-flash)
              </p>
            </div>
          </div>

          {/* Main Stage Panel Screen */}
          <div className="lg:col-span-9 order-1 lg:order-2 bg-slate-900/20 border border-slate-900/50 rounded-3xl p-6 md:p-8 backdrop-blur-md shadow-2xl relative overflow-hidden">
            {/* Hologram aesthetic stripes */}
            <div className="absolute inset-0 bg-[linear-gradient(rgba(18,24,38,0.2)_1px,transparent_1px)] bg-[size:100%_4px] pointer-events-none z-0"></div>
            
            <AnimatePresence mode="wait">
              
              {/* Tab 1: Names generator */}
              {activeTab === "names" && (
                <motion.div
                  key="names"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-6 relative z-10"
                >
                  <div className="border-b border-slate-900/80 pb-4 text-right">
                    <h2 className="text-xl font-bold font-[Cairo] text-white flex items-center justify-end gap-2.5">
                      <span>مولد الأسماء وألقاب اللاعبين بالذكاء الاصطناعي</span>
                      <span className="text-2xl">🤖</span>
                    </h2>
                    <p className="text-xs text-slate-400 font-[Tajawal] mt-1">امنح هويتك الرقمية فرادة وغموضاً فريداً بأساليب متعددة مستوحاة من عوالم المتروبوليس السيبراني.</p>
                  </div>

                  {/* Input Form Fields */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-right">
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-400 font-[Cairo]">نوع الهوية / نمط اللقب:</label>
                      <select 
                        value={nameMode} 
                        onChange={(e) => setNameMode(e.target.value)}
                        className="w-full bg-slate-950/80 text-xs border border-slate-800 focus:border-purple-500/50 px-3.5 py-3 rounded-xl focus:outline-none font-bold text-slate-300 font-[Cairo]"
                      >
                        <option value="individual">لاعب فردي (Individual Gamertag)</option>
                        <option value="clan">اسم كلان / عشيرة (Clan name)</option>
                        <option value="esports">لاعب رياضات إلكترونية محترف (Pro Esports Tag)</option>
                        <option value="professional">لقب غامض مرعب (Futuristic Shadow Title)</option>
                      </select>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-400 font-[Cairo]">طابع اللقب ونبرة التوليد:</label>
                      <select 
                        value={nameStyle} 
                        onChange={(e) => setNameStyle(e.target.value)}
                        className="w-full bg-slate-950/80 text-xs border border-slate-800 focus:border-purple-500/50 px-3.5 py-3 rounded-xl focus:outline-none font-bold text-slate-300 font-[Cairo]"
                      >
                        <option value="cyberpunk">سايبربانك ونيون مستقبلي (Cyberpunk Neon)</option>
                        <option value="dark">قوطي غامق ومرعب (Dark Gothic Shadow)</option>
                        <option value="fantasy">خيالي ملحمي وأساطير التنانين (Epic Fantasy Knight)</option>
                        <option value="legendary">ساحق وإمبراطوري تنافسي (Gladiator Conquest)</option>
                      </select>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-400 font-[Cairo]">لغة اللقب الأساسية:</label>
                      <select 
                        value={nameLang} 
                        onChange={(e) => setNameLang(e.target.value)}
                        className="w-full bg-slate-950/80 text-xs border border-slate-800 focus:border-purple-500/50 px-3.5 py-3 rounded-xl focus:outline-none font-bold text-slate-300 font-[Cairo]"
                      >
                        <option value="mix">مزيج عربي إنجليزي فخم (Hybrid Arab-Slang)</option>
                        <option value="ar">عربي نقي فصيح مهيب (Pure Majestic Arabic)</option>
                        <option value="en">إنجليزي سايبر عالي الجودة (Cyber English Moniker)</option>
                      </select>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-400 font-[Cairo]">أحرف أو كلمة مفضلة للدمج (اختياري):</label>
                      <input 
                        type="text" 
                        value={nameLetters}
                        onChange={(e) => { 
                          setNameLetters(e.target.value);
                          setNameIsRandom(!e.target.value);
                        }}
                        placeholder="مثال: X, Viper, قناص..."
                        className="w-full bg-slate-950/80 text-xs border border-slate-800 focus:border-purple-500/50 px-3.5 py-3 rounded-xl focus:outline-none text-right text-slate-300 font-[Cairo]"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end pt-3">
                    <button 
                      onClick={handleGenerateNames}
                      disabled={loadingNames}
                      className="inline-flex items-center gap-2 px-7 py-3.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 shadow-lg shadow-purple-500/10 font-bold text-xs text-white transition font-[Cairo]"
                    >
                      {loadingNames ? (
                        <>
                          <RefreshCw className="w-4 h-4 animate-spin" />
                          <span>جاري صقل الأسماء واستشارة العقل..</span>
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-4 h-4 text-purple-200" />
                          <span>ابدأ توليد الأسماء السيبرانية الفاخرة</span>
                        </>
                      )}
                    </button>
                  </div>

                  {/* Generated results output */}
                  {generatedNames.length > 0 && (
                    <motion.div 
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="space-y-4 pt-4"
                    >
                      <div className="flex items-center justify-between border-t border-slate-900/80 pt-4 flex-row-reverse">
                        <h4 className="text-xs font-mono font-bold text-purple-400 tracking-wider">GENERATED COGNITIVE ALIASES</h4>
                        <span className="text-[10px] text-slate-500 font-[Tajawal]">انقر لنسخ الاسم المفضل مباشرة</span>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {generatedNames.map((n, idx) => (
                          <div 
                            key={idx}
                            onClick={() => handleCopyToClipboard(n.name)}
                            className="p-4 bg-slate-950/60 border border-slate-900 hover:border-purple-500/20 rounded-2xl text-right transition cursor-pointer relative group overflow-hidden"
                          >
                            <div className="absolute top-2.5 left-2.5 opacity-0 group-hover:opacity-100 transition duration-200">
                              {copiedText === n.name ? (
                                <Check className="w-4 h-4 text-emerald-400" />
                              ) : (
                                <Copy className="w-4 h-4 text-slate-500 hover:text-white" />
                              )}
                            </div>
                            
                            <h5 className="text-base font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-400 font-mono mb-2">
                              {n.name}
                            </h5>
                            <p className="text-[11px] text-slate-400 leading-relaxed font-[Tajawal]">
                              {n.story}
                            </p>
                          </div>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </motion.div>
              )}

              {/* Tab 2: Code visualizer / avatars */}
              {activeTab === "avatars" && (
                <motion.div
                  key="avatars"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-6 relative z-10"
                >
                  <div className="border-b border-slate-900/80 pb-4 text-right">
                    <h2 className="text-xl font-bold font-[Cairo] text-white flex items-center justify-end gap-2.5">
                      <span>مصمم الأفاتار وتوجيهات الهوية الرمزية للأساطير</span>
                      <span className="text-2xl">🎨</span>
                    </h2>
                    <p className="text-xs text-slate-400 font-[Tajawal] mt-1">قم بهيكلة موجهات (Prompts) متناهية الدقة لتوليد شعارات الألعاب الاحترافية وقنوات ستيم والديسكورد مع محاكي توليد رمزي حي ومستجيب.</p>
                  </div>

                  {/* Input Form Fields */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-right">
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-400 font-[Cairo]">ثيم ونمط الهوية البصرية:</label>
                      <select 
                        value={avatarStyle} 
                        onChange={(e) => setAvatarStyle(e.target.value)}
                        className="w-full bg-slate-950/80 text-xs border border-slate-800 focus:border-purple-500/50 px-3.5 py-3 rounded-xl focus:outline-none font-bold text-slate-300 font-[Cairo]"
                      >
                        <option value="RGB Tech Neon Setup">نيون جيمنج وبث أسطوري (RGB Streamer Setup)</option>
                        <option value="Cyberpunk Elite Hacker">سايبربانك وذكي شبكات غامض (Ghost Hacker)</option>
                        <option value="Mecha Anime Robotic Armor">درع آلي ياباني مكا (Mecha Anime Robot)</option>
                        <option value="Retro 16-bit Pixel Art">بكسل آرت عتيق كلاسيكي (Retro Pixel Knight)</option>
                        <option value="Elite Esports Tactical Mascot">تميمة رياضات تنافسية شرسة (Esports Monster Mascot)</option>
                      </select>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-400 font-[Cairo]">موضوع وشخصية الشعار الرئيسي:</label>
                      <select 
                        value={avatarType} 
                        onChange={(e) => setAvatarType(e.target.value)}
                        className="w-full bg-slate-950/80 text-xs border border-slate-800 focus:border-purple-500/50 px-3.5 py-3 rounded-xl focus:outline-none font-bold text-slate-300 font-[Cairo]"
                      >
                        <option value="humanoid cyborg">رجل كربوني نصف آلي (Humanoid Cyborg)</option>
                        <option value="animal bio-cyber">حيوان كوانتومي متوحش (Cyber Wolf/Tiger)</option>
                        <option value="abstract geometric matrix">تمثيلات هندسية غامضة (Abstract Neon Glyph)</option>
                        <option value="skull gaming reaper">جمجمة كابتن ومحارب ميت (Tactical Helmet Skull)</option>
                      </select>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-400 font-[Cairo]">ألوان الإضاءة التوجيهية الأساسية:</label>
                      <div className="flex gap-2 justify-end py-1">
                        <button 
                          onClick={() => setAvatarColor(["#a855f7", "#06b6d4"])}
                          className={`w-8 h-8 rounded-full border-2 ${avatarColor[0] === "#a855f7" ? "border-white" : "border-transparent"} bg-gradient-to-r from-purple-500 to-cyan-500`}
                          title="Neon Purple & Cyan"
                        ></button>
                        <button 
                          onClick={() => setAvatarColor(["#ef4444", "#eab308"])}
                          className={`w-8 h-8 rounded-full border-2 ${avatarColor[0] === "#ef4444" ? "border-white" : "border-transparent"} bg-gradient-to-r from-red-500 to-yellow-500`}
                          title="Cyberpunk Red & Yellow"
                        ></button>
                        <button 
                          onClick={() => setAvatarColor(["#22c55e", "#0ea5e9"])}
                          className={`w-8 h-8 rounded-full border-2 ${avatarColor[0] === "#22c55e" ? "border-white" : "border-transparent"} bg-gradient-to-r from-emerald-500 to-sky-500`}
                          title="Hacker Green & Sky"
                        ></button>
                        <button 
                          onClick={() => setAvatarColor(["#ec4899", "#f43f5e"])}
                          className={`w-8 h-8 rounded-full border-2 ${avatarColor[0] === "#ec4899" ? "border-white" : "border-transparent"} bg-gradient-to-r from-pink-500 to-rose-500`}
                          title="Cyberpink & Rose Glow"
                        ></button>
                      </div>
                    </div>
                  </div>

                  <div className="flex justify-end pt-3">
                    <button 
                      onClick={handleGenerateAvatars}
                      disabled={loadingAvatars}
                      className="inline-flex items-center gap-2 px-7 py-3.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 shadow-lg shadow-purple-500/10 font-bold text-xs text-white transition font-[Cairo]"
                    >
                      {loadingAvatars ? (
                        <>
                          <RefreshCw className="w-4 h-4 animate-spin" />
                          <span>جاري صياغة الكود والسيناريوهات الهيكلية..</span>
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-4 h-4 text-purple-200" />
                          <span>صمم مفاهيم الهوية الرمزية الثورية</span>
                        </>
                      )}
                    </button>
                  </div>

                  {/* Results: Concepts with LIVE customizable Interactive SVG Avatar previews */}
                  {generatedAvatars.length > 0 && (
                    <motion.div 
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="space-y-6 pt-4"
                    >
                      <div className="flex items-center justify-between border-t border-slate-900/80 pt-4 flex-row-reverse">
                        <h4 className="text-xs font-mono font-bold text-purple-400 tracking-wider">INTERACTIVE VISUAL IDENTITY CONCEPTS</h4>
                        <span className="text-[10px] text-slate-500 font-[Tajawal]">الذكاء الاصطناعي ولّد 4 مسودات فنية مهيبة مع موجهات الميدجورني المدمجة</span>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {generatedAvatars.map((c, idx) => {
                          const customSeedVal = avatarCustomSeeds[idx] || c.seed;
                          const botttsAvatarUrl = `https://api.dicebear.com/7.x/bottts/svg?seed=${customSeedVal}&backgroundColor=111827&ringRadius=30`;
                          return (
                            <div 
                              key={idx}
                              className="p-5 bg-slate-950/80 border border-slate-900 rounded-3xl text-right transition hover:border-slate-800 flex flex-col md:flex-row-reverse gap-4 justify-between"
                            >
                              {/* Live Customizable Mock Avatar Display box */}
                              <div className="flex flex-col items-center gap-3 shrink-0">
                                <div className="w-24 h-24 rounded-2xl bg-slate-900 border border-slate-800 p-1 divide-y divide-slate-800 flex items-center justify-center overflow-hidden relative group">
                                  <img 
                                    src={botttsAvatarUrl} 
                                    alt="Live Avatar Identity preview" 
                                    className="w-full h-full object-contain rounded-xl"
                                    referrerPolicy="no-referrer"
                                  />
                                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex items-center justify-center text-[10px] font-bold font-[Cairo]">
                                    معاينة تفاعلية حية
                                  </div>
                                </div>
                                <button 
                                  onClick={() => {
                                    setAvatarCustomSeeds({
                                      ...avatarCustomSeeds,
                                      [idx]: "seed-" + Math.floor(Math.random() * 99999)
                                    });
                                  }}
                                  className="px-2 py-1 bg-slate-900/80 border border-slate-800 rounded text-[9px] hover:text-cyan-400 transition flex items-center gap-1 font-bold font-[Cairo]"
                                >
                                  <RefreshCw className="w-2.5 h-2.5" />
                                  عشوائي
                                </button>
                              </div>

                              {/* Concept textual details */}
                              <div className="flex-grow space-y-2 text-right">
                                <h5 className="text-sm font-bold text-purple-300 font-[Cairo]">{c.title}</h5>
                                <p className="text-[10px] text-slate-400 font-[Tajawal] leading-relaxed mb-3">
                                  {c.description}
                                </p>
                                
                                <div className="space-y-1">
                                  <span className="text-[9px] font-mono font-bold text-slate-500 block uppercase tracking-wider">MIDJOURNEY ENHANCED PROMPT</span>
                                  <div className="bg-slate-900 border border-slate-800 rounded-xl p-2.5 font-mono text-[9px] text-cyan-300 relative group text-left select-all">
                                    <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition">
                                      <button 
                                        onClick={() => handleCopyToClipboard(c.prompt)}
                                        className="p-1 rounded bg-slate-950 text-slate-400 hover:text-white"
                                        title="Copy prompt"
                                      >
                                        {copiedText === c.prompt ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                                      </button>
                                    </div>
                                    {c.prompt}
                                  </div>
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </motion.div>
                  )}
                </motion.div>
              )}

              {/* Tab 3: Recommendations dialer */}
              {activeTab === "recs" && (
                <motion.div
                  key="recs"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-6 relative z-10"
                >
                  <div className="border-b border-slate-900/80 pb-4 text-right">
                    <h2 className="text-xl font-bold font-[Cairo] text-white flex items-center justify-end gap-2.5">
                      <span>عرّاف الألعاب التنبؤي والترشيحات المخصصة بحسب المزاج</span>
                      <span className="text-2xl">🔮</span>
                    </h2>
                    <p className="text-xs text-slate-400 font-[Tajawal] mt-1">دع العقل الراداري يرتب لك تحفة الألعاب المفضلة التالية بدقة مطلقة، مع معلومات حقيقية 100% موائمة لسيناريوهات لعبك السابقة ونوع العتاد.</p>
                  </div>

                  {/* Input Form Fields */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-right">
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-400 font-[Cairo]">اكتب 2 إلى 3 ألعاب تحبها كثيراً حالياً:</label>
                      <input 
                        type="text" 
                        value={similarGamesInput}
                        onChange={(e) => setSimilarGamesInput(e.target.value)}
                        placeholder="مثال: Elden Ring, Cyberpunk 2077, GTA V..."
                        className="w-full bg-slate-950/80 text-xs border border-slate-800 focus:border-purple-500/50 px-3.5 py-3 rounded-xl focus:outline-none text-right text-slate-300 font-[Cairo]"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-400 font-[Cairo]">الحالة النفسية والمزاج المطلوب حالياً للاعب:</label>
                      <select 
                        value={gamerMood} 
                        onChange={(e) => setGamerMood(e.target.value)}
                        className="w-full bg-slate-950/80 text-xs border border-slate-800 focus:border-purple-500/50 px-3.5 py-3 rounded-xl focus:outline-none font-bold text-slate-300 font-[Cairo]"
                      >
                        <option value="intense battlefield sweat and rage-clutch">تحدي وحماسة بالغة مميتة وعرق (Intense Battlefield Sweat)</option>
                        <option value="relaxing deep immersive storyline exploration">قصة غامضة عميقة واستكشاف دافئ مريح (Deep Storyline Immersion)</option>
                        <option value="high-speed adrenaline adrenaline action dopamine">أدرينالين حركي وتدمير سيارات ومطاردات (High-Speed Action Dopamine)</option>
                        <option value="mind-bending puzzle logic and tactics">إجهاد ذهني وألغاز وتكتيك عبقري (Mind-Bending Tactical Puzzle)</option>
                        <option value="cozy indie multiplayer pixel and relaxing vibes">ألعاب إيندي كرتونية لطيفة للبناء والاسترخاء (Cozy Relaxing pixel Art)</option>
                      </select>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-400 font-[Cairo]">نمط ومستوى التحكم المفضل:</label>
                      <div className="flex gap-2 justify-end">
                        <button 
                          onClick={() => setGameplayPreference("competitive")}
                          className={`px-4 py-2 border rounded-xl text-xs font-bold font-[Cairo] transition ${
                            gameplayPreference === "competitive" 
                              ? "bg-purple-600/20 border-purple-500 text-purple-200" 
                              : "border-slate-800 bg-slate-950/40 text-slate-400"
                          }`}
                        >
                          رياضات تنافسية / فريمات عالية
                        </button>
                        <button 
                          onClick={() => setGameplayPreference("casual")}
                          className={`px-4 py-2 border rounded-xl text-xs font-bold font-[Cairo] transition ${
                            gameplayPreference === "casual" 
                              ? "bg-purple-600/20 border-purple-500 text-purple-200" 
                              : "border-slate-800 bg-slate-950/40 text-slate-400"
                          }`}
                        >
                          تسلية فردية سينمائية / قصة وغوص
                        </button>
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-400 font-[Cairo]">العناوين وأنواع الألعاب المفضل رصدها:</label>
                      <div className="flex flex-wrap gap-1.5 justify-end">
                        {["RPG", "Action", "Open World", "Shooter (FPS)", "Horror", "Strategy", "Survival", "Sci-Fi"].map((g) => {
                          const isSelected = selectedSpecGenres.includes(g);
                          return (
                            <button
                              key={g} 
                              onClick={() => handleToggleGenre(g)}
                              className={`px-2.5 py-1.5 border rounded-lg text-[10px] font-mono transition ${
                                isSelected ? "bg-cyan-500/20 border-cyan-500/50 text-cyan-300" : "border-slate-900 bg-slate-950/80 text-slate-500"
                              }`}
                            >
                              {isSelected ? "✓ " : ""} {g}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>

                  <div className="flex justify-end pt-3">
                    <button 
                      onClick={handleGenerateRecommendations}
                      disabled={loadingRecs}
                      className="inline-flex items-center gap-2 px-7 py-3.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 shadow-lg shadow-purple-500/10 font-bold text-xs text-white transition font-[Cairo]"
                    >
                      {loadingRecs ? (
                        <>
                          <RefreshCw className="w-4 h-4 animate-spin" />
                          <span>جاري تدوير فلك الألعاب المحايد والتنبؤ..</span>
                        </>
                      ) : (
                        <>
                          <Compass className="w-4 h-4 text-purple-200 hover:rotate-180 transition-transform duration-500" />
                          <span>تنبأ بالألعاب المثالية لي الآن</span>
                        </>
                      )}
                    </button>
                  </div>

                  {/* Recommendation list output */}
                  {recsList.length > 0 && (
                    <motion.div 
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="space-y-4 pt-4"
                    >
                      <div className="flex items-center justify-between border-t border-slate-900/80 pt-4 flex-row-reverse">
                        <h4 className="text-xs font-mono font-bold text-purple-400 tracking-wider">AI PREDICTIVE RECOMMENDED GAMES</h4>
                        <span className="text-[10px] text-slate-500 font-[Tajawal]">تفاصيل الألعاب صحيحة 100% مستوفاة للذوق الشخصي</span>
                      </div>

                      <div className="space-y-3">
                        {recsList.map((rec, idx) => (
                          <div 
                            key={idx}
                            className="p-5 bg-gradient-to-r from-slate-950 text-right via-slate-950/90 to-slate-900/10 border border-slate-900 hover:border-slate-800 rounded-2xl flex flex-col md:flex-row-reverse gap-4 justify-between"
                          >
                            <div className="md:w-32 h-20 shrink-0 rounded-xl bg-slate-900 border border-slate-800 overflow-hidden flex items-center justify-center relative">
                              <img 
                                src={rec.imageUrl || "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=400"} 
                                alt={rec.title} 
                                className="w-full h-full object-cover"
                                referrerPolicy="no-referrer"
                              />
                              <div className="absolute top-1 right-1 bg-cyan-950/80 border border-cyan-500/30 text-cyan-400 text-[10px] font-mono px-1.5 py-0.5 rounded">
                                {rec.releaseYear}
                              </div>
                            </div>

                            <div className="flex-grow space-y-1.5">
                              <div className="flex items-center gap-2 justify-end mb-1">
                                <span className="text-[10px] font-mono bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded text-emerald-400 font-bold">
                                  نسبة المطابقة %{rec.matchRate || 95}
                                </span>
                                <h5 className="text-sm font-black text-white font-[Cairo]">{rec.title}</h5>
                              </div>
                              
                              <p className="text-[11px] text-slate-400 font-[Tajawal] leading-relaxed">
                                {rec.description}
                              </p>

                              <div className="flex gap-2.5 justify-end text-[10px] text-slate-500 font-mono">
                                <span>Platform(s): {rec.platform}</span>
                                <span>•</span>
                                <span>Game ID Ref: #{idx + 1}</span>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </motion.div>
              )}

              {/* Tab 4: FPS optimization diagnostics */}
              {activeTab === "fps" && (
                <motion.div
                  key="fps"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-6 relative z-10"
                >
                  <div className="border-b border-slate-900/80 pb-4 text-right">
                    <h2 className="text-xl font-bold font-[Cairo] text-white flex items-center justify-end gap-2.5">
                      <span>مساعد ومستشار ترقية وضبط إطارات الألعاب (FPS-Boost Engine)</span>
                      <span className="text-2xl">⚡</span>
                    </h2>
                    <p className="text-xs text-slate-400 font-[Tajawal] mt-1">احقن كرت الشاشة والتحكم بأقوى تهيئات كسر السرعة لضمان تماسك الإطارات وتحسين استهلاك الموارد المئوي.</p>
                  </div>

                  {/* Input form hardware fields */}
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-right">
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-400 font-[Cairo]">اللعبة المراد تهيئتها لكرتك:</label>
                      <input 
                        type="text" 
                        value={optGameName}
                        onChange={(e) => setOptGameName(e.target.value)}
                        placeholder="مثال: Special Force, Valorant, GTA V..."
                        className="w-full bg-slate-950/80 text-xs border border-slate-800 focus:border-purple-500/50 px-3.5 py-3 rounded-xl focus:outline-none text-right text-slate-300 font-[Cairo]"
                        required
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-400 font-[Cairo]">المعالج الرئيسي (CPU):</label>
                      <input 
                        type="text" 
                        value={optCpu}
                        onChange={(e) => setOptCpu(e.target.value)}
                        placeholder="مثال: Intel i5-12400F, Ryzen 5 5600X..."
                        className="w-full bg-slate-950/80 text-xs border border-slate-800 focus:border-purple-500/50 px-3.5 py-3 rounded-xl focus:outline-none text-right text-slate-300 font-[Cairo]"
                        required
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-400 font-[Cairo]">كرت الشاشة (GPU):</label>
                      <input 
                        type="text" 
                        value={optGpu}
                        onChange={(e) => setOptGpu(e.target.value)}
                        placeholder="مثال: NVIDIA RTX 4060, RX 7600 XT..."
                        className="w-full bg-slate-950/80 text-xs border border-slate-800 focus:border-purple-500/50 px-3.5 py-3 rounded-xl focus:outline-none text-right text-slate-300 font-[Cairo]"
                        required
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-400 font-[Cairo]">سعة الذاكرة العشوائية (RAM):</label>
                      <select 
                        value={optRam} 
                        onChange={(e) => setOptRam(e.target.value)}
                        className="w-full bg-slate-950/80 text-xs border border-slate-800 focus:border-purple-500/50 px-3.5 py-3 rounded-xl focus:outline-none font-bold text-slate-300 font-[Cairo]"
                      >
                        <option value="8 GB">8 GB RAM DDR4</option>
                        <option value="16 GB">16 GB RAM Dual Channel</option>
                        <option value="32 GB">32 GB RAM DDR5 Extreme</option>
                        <option value="64 GB">64 GB RAM Enterprise Server</option>
                      </select>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-400 font-[Cairo]">الهدف الأساسي من التعديل:</label>
                      <select 
                        value={optGoal} 
                        onChange={(e) => setOptGoal(e.target.value)}
                        className="w-full bg-slate-950/80 text-xs border border-slate-800 focus:border-purple-500/50 px-3.5 py-3 rounded-xl focus:outline-none font-bold text-slate-300 font-[Cairo]"
                      >
                        <option value="fps">أقصى كفاءة فريمات وتقليص لاغ (Max FPS Boost)</option>
                        <option value="quality">أقصى جودة بصرية سينمائية (Ultra RayTracing Graphics)</option>
                        <option value="balanced">موازنة متناغمة هادئة (Optimized Equilibrium)</option>
                      </select>
                    </div>
                  </div>

                  <div className="flex justify-end pt-3">
                    <button 
                      onClick={handleGenerateOptimizations}
                      disabled={loadingOptimizer || !optGameName}
                      className="inline-flex items-center gap-2 px-7 py-3.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 shadow-lg shadow-purple-500/10 font-bold text-xs text-white transition font-[Cairo] disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {loadingOptimizer ? (
                        <>
                          <RefreshCw className="w-4 h-4 animate-spin" />
                          <span>جاري فحص النواة وخطوط عنق الزجاجة..</span>
                        </>
                      ) : (
                        <>
                          <Cpu className="w-4 h-4 text-cyan-300 animate-pulse" />
                          <span>ابدأ تحليل العتاد ورفع الفريمات</span>
                        </>
                      )}
                    </button>
                  </div>

                  {/* Diagnostics results box layout */}
                  {optimizationsResult && (
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.98 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="space-y-6 pt-4 border-t border-slate-900"
                    >
                      {/* Metric Dashboard blocks */}
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
                        <div className="bg-slate-950/60 p-4 border border-slate-900 rounded-2xl relative overflow-hidden">
                          <span className="text-[10px] font-mono text-slate-500 block">ESTIMATED SPEED HARVEST</span>
                          <span className="text-2xl font-black text-emerald-400 font-mono animate-pulse block mt-1">
                            {optimizationsResult.fpsIncreaseEstimate}
                          </span>
                          <span className="text-[10px] text-slate-400 font-[Cairo] mt-1 block">زيادة متوقعة في سلاسة عرض الحركة</span>
                        </div>

                        <div className="bg-slate-950/60 p-4 border border-slate-900 rounded-2xl relative overflow-hidden">
                          <span className="text-[10px] font-mono text-slate-500 block">LATENCY SLASHED DELAY</span>
                          <span className="text-2xl font-black text-cyan-400 font-mono block mt-1">
                            {optimizationsResult.latencyDecrease}
                          </span>
                          <span className="text-[10px] text-slate-400 font-[Cairo] mt-1 block">تقليص نسبة تأخر الاستجابة المباشرة</span>
                        </div>

                        <div className="bg-slate-950/60 p-4 border border-slate-950/80 rounded-2xl md:col-span-1 relative flex flex-col justify-center items-center px-4">
                          <span className="flex items-center gap-1 text-[10px] font-bold text-slate-500 mb-0.5">
                            <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                            DIAGNOSTICS OK
                          </span>
                          <span className="text-[10px] text-slate-400 font-[Tajawal] leading-tight text-center mt-1">
                            نظام الاستدلال فحص معالجات العتاد بنجاح تام
                          </span>
                        </div>
                      </div>

                      {/* Technical Bottleneck Assessment */}
                      <div className="p-4 bg-purple-950/10 border border-purple-500/10 rounded-2xl text-right">
                        <h4 className="text-xs font-black text-purple-300 font-[Cairo] mb-1">🔍 مراجعة عنق زجاجة العتاد (Bottleneck Verdict):</h4>
                        <p className="text-[11px] text-slate-400 leading-relaxed font-[Tajawal]">
                          {optimizationsResult.bottleneckCheck}
                        </p>
                      </div>

                      {/* Side by side optimizations lists */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-right">
                        <div className="space-y-3">
                          <h4 className="text-xs font-bold text-slate-400 font-[Cairo]">⚙️ الإعدادات الموصى بها داخل اللعبة (In-Game Menu):</h4>
                          <div className="bg-slate-950/80 border border-slate-900 p-3.5 rounded-2xl space-y-2 font-mono text-xs text-slate-300">
                            {optimizationsResult.inGameConfig.map((item: any, i: number) => (
                              <div key={i} className="flex justify-between items-center py-1.5 border-b border-slate-900 last:border-0">
                                <span className="text-purple-400 font-bold font-[Cairo]">{item.recommendation}</span>
                                <span className="font-mono text-slate-400 text-[11px] text-right">{item.setting}</span>
                              </div>
                            ))}
                          </div>
                        </div>

                        <div className="space-y-3">
                          <h4 className="text-xs font-bold text-slate-400 font-[Cairo]">🛠️ تعديلات نظام التشغيل والكرت (Windows OS & Control Panel):</h4>
                          <ul className="space-y-2 bg-slate-950/40 p-4 border border-slate-900 rounded-2xl text-slate-400 font-[Tajawal] text-xs">
                            {optimizationsResult.systemOptimizations.map((item: string, i: number) => (
                              <li key={i} className="flex items-start gap-2 justify-end text-right">
                                <span className="text-slate-300">{item}</span>
                                <span className="text-cyan-400 font-bold shrink-0">◀</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </motion.div>
              )}

              {/* Tab 5: RGB Setup Planner */}
              {activeTab === "rgb" && (
                <motion.div
                  key="rgb"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-6 relative z-10"
                >
                  <div className="border-b border-slate-900/80 pb-4 text-right">
                    <h2 className="text-xl font-bold font-[Cairo] text-white flex items-center justify-end gap-2.5">
                      <span>هندسة الغرف وأجواء الإضاءة والخلفيات المتناغمة (RGB Ambient Lab)</span>
                      <span className="text-2xl">💡</span>
                    </h2>
                    <p className="text-xs text-slate-400 font-[Tajawal] mt-1">احصل على دليل تهيئة وتنسيق إضاءة غرفتك والبي سي بالكامل مع خلفيات حقيقية لتهيئة مكتبك الخاص.</p>
                  </div>

                  {/* Input form fields */}
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-right">
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-400 font-[Cairo]">تخطيط وهيكل مساحتك:</label>
                      <select 
                        value={setupLayout} 
                        onChange={(e) => setSetupLayout(e.target.value)}
                        className="w-full bg-slate-950/80 text-xs border border-slate-800 focus:border-purple-500/50 px-3.5 py-3 rounded-xl focus:outline-none font-bold text-slate-300 font-[Cairo]"
                      >
                        <option value="minimal-desk">مكتب جيمنج بسيط شاشة واحدة (Minimal Clean Desk)</option>
                        <option value="dual-monitor-setup">مكتب مزدوج الشاشات احترافي (Dual Monitor setup)</option>
                        <option value="full-bedroom">غرفة نوم كاملة مجهزة بالكامل (Ultimate RGB Bedrooms)</option>
                        <option value="cozy-console-corner">ركن الأريكة والكونسول والتلفزيون (Cozy Console Nook)</option>
                      </select>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-400 font-[Cairo]">اللون الأساسي للإضاءة (Accent Primary):</label>
                      <input 
                        type="color" 
                        value={primaryColor}
                        onChange={(e) => setPrimaryColor(e.target.value)}
                        className="w-full h-11 bg-slate-950/80 border border-slate-800 rounded-xl cursor-pointer"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-400 font-[Cairo]">اللون المتمم للإضاءة (Accent Secondary):</label>
                      <input 
                        type="color" 
                        value={secondaryColor}
                        onChange={(e) => setSecondaryColor(e.target.value)}
                        className="w-full h-11 bg-slate-950/80 border border-slate-800 rounded-xl cursor-pointer"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-400 font-[Cairo]">أتموسفير الأجواء العام (Vibe Theme):</label>
                      <select 
                        value={setupVibes} 
                        onChange={(e) => setSetupVibes(e.target.value)}
                        className="w-full bg-slate-950/80 text-xs border border-slate-800 focus:border-purple-500/50 px-3.5 py-3 rounded-xl focus:outline-none font-bold text-slate-300 font-[Cairo]"
                      >
                        <option value="Synthwave Sunset">غروب شمس السنثويف الدافئ (Synthwave Sunset)</option>
                        <option value="Tokyo Midnight Cyberpunk">نيون طوكيو بعد منتصف الليل (Tokyo Midnight)</option>
                        <option value="Cozy Warm Wood Cabin">غابة وأكواخ دافئة مريحة (Cozy Warm Cabin)</option>
                        <option value="The Matrix Code Green">ترميز الماتريكس الأخضر الغامض (Matrix Green)</option>
                      </select>
                    </div>
                  </div>

                  <div className="flex justify-end pt-3">
                    <button 
                      onClick={handleGenerateRgb}
                      disabled={loadingRgb}
                      className="inline-flex items-center gap-2 px-7 py-3.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 shadow-lg shadow-purple-500/10 font-bold text-xs text-white transition font-[Cairo]"
                    >
                      {loadingRgb ? (
                        <>
                          <RefreshCw className="w-4 h-4 animate-spin" />
                          <span>جاري خلط التدرجات وهندسة الأبعاد المحيطية..</span>
                        </>
                      ) : (
                        <>
                          <Palette className="w-4 h-4 text-purple-200" />
                          <span>ابدأ هندسة غرفتك الاحترافية</span>
                        </>
                      )}
                    </button>
                  </div>

                  {/* Generated results details with responsive visual colors display block */}
                  {rgbThemeResult && (
                    <motion.div 
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="space-y-6 pt-4 border-t border-slate-900"
                    >
                      <div className="flex flex-col md:flex-row-reverse gap-6 items-start">
                        
                        {/* Live CSS Color gradient border layout visualizer */}
                        <div className="w-full md:w-1/3 space-y-4 shrink-0 text-right">
                          <h4 className="text-xs font-bold text-slate-400 font-[Cairo]">🌈 تدرجات الألوان الفنية لغرفتك:</h4>
                          
                          <div 
                            className="h-32 rounded-3xl p-1 relative overflow-hidden flex items-end justify-center shadow-lg transition duration-500"
                            style={{
                              background: `linear-gradient(135deg, ${rgbThemeResult.cssColors[0] || primaryColor}, ${rgbThemeResult.cssColors[1] || secondaryColor}, ${rgbThemeResult.cssColors[2] || "#1e1b4b"})`
                            }}
                          >
                            <div className="absolute inset-0.5 bg-slate-950/90 rounded-[22px] backdrop-blur flex flex-col justify-center items-center text-center p-3">
                              <span className="text-xs text-slate-500 font-mono uppercase">Applied Palette</span>
                              <strong className="text-sm font-black text-white font-[Cairo] mt-1">{rgbThemeResult.themeName}</strong>
                            </div>
                          </div>

                          <div className="flex gap-2 justify-center">
                            {rgbThemeResult.cssColors.map((hex: string, i: number) => (
                              <div 
                                key={i}
                                className="flex flex-col items-center gap-1 cursor-pointer"
                                onClick={() => handleCopyToClipboard(hex)}
                              >
                                <div className="w-8 h-8 rounded-full border border-slate-800" style={{ backgroundColor: hex }}></div>
                                <span className="text-[9px] font-mono text-slate-500">{hex}</span>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Layout description */}
                        <div className="flex-grow space-y-4 text-right">
                          <div>
                            <span className="text-[10px] font-mono text-purple-400 uppercase font-black block">WORKSPACE LIGHTING ARCHITECTURE</span>
                            <h3 className="text-base font-bold text-white font-[Cairo] mt-1">تخطيط توزيع الإضاءة المحيطية:</h3>
                            <p className="text-xs text-slate-400 leading-relaxed font-[Tajawal] mt-1.5">
                              {rgbThemeResult.lightingLayout}
                            </p>
                          </div>

                          <div>
                            <h4 className="text-xs font-bold text-purple-300 font-[Cairo]">🖥️ محفزات اختيار الخلفية لسطح المكتب (Wallpapers):</h4>
                            <p className="text-xs text-slate-400 font-[Tajawal] leading-relaxed mt-1">
                              {rgbThemeResult.wallpapers}
                            </p>
                          </div>

                          <div>
                            <h4 className="text-xs font-bold text-purple-300 font-[Cairo] mb-1.5">🎁 الإكسسوارات المحيطة المقترحة للغرفة والكونسول:</h4>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-right">
                              {rgbThemeResult.accessories.map((acc: string, i: number) => (
                                <div key={i} className="p-3 bg-slate-950/60 border border-slate-900 rounded-xl">
                                  <span className="text-xs font-bold text-slate-200 font-[Cairo] block">{acc}</span>
                                  <span className="text-[9px] font-mono text-slate-500 block">Accessory #{i + 1}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </motion.div>
              )}

              {/* Tab 6: Streamer creator hooks */}
              {activeTab === "creator" && (
                <motion.div
                  key="creator"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-6 relative z-10"
                >
                  <div className="border-b border-slate-900/80 pb-4 text-right">
                    <h2 className="text-xl font-bold font-[Cairo] text-white flex items-center justify-end gap-2.5">
                      <span>مولد خطافات البث وأفكار صناع المحتوى الفيروسية (Viral Loops)</span>
                      <span className="text-2xl">🎥</span>
                    </h2>
                    <p className="text-xs text-slate-400 font-[Tajawal] mt-1">لأصحاب قنوات اليوتيوب، التيك توك وتويتش. صمم خطافات للمقاطع مفرغة ومجهزة للوصول المليوني فوراً.</p>
                  </div>

                  {/* Input form fields */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-right">
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-400 font-[Cairo]">المنصة المستهدفة للنشر:</label>
                      <select 
                        value={creatorPlatform} 
                        onChange={(e) => setCreatorPlatform(e.target.value)}
                        className="w-full bg-slate-950/80 text-xs border border-slate-800 focus:border-purple-500/50 px-3.5 py-3 rounded-xl focus:outline-none font-bold text-slate-300 font-[Cairo]"
                      >
                        <option value="tiktok">تيك توك ومقاطع قصيرة (TikTok / Reels)</option>
                        <option value="youtube">يوتيوب أساسي وفيديوهات طويلة (YouTube Standard)</option>
                        <option value="twitch">تويتش وبث مباشر وتفاعل (Twitch Highlights)</option>
                      </select>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-400 font-[Cairo]">أسلوب وطابع تصوير الفيديو:</label>
                      <select 
                        value={creatorVibe} 
                        onChange={(e) => setCreatorVibe(e.target.value)}
                        className="w-full bg-slate-950/80 text-xs border border-slate-800 focus:border-purple-500/50 px-3.5 py-3 rounded-xl focus:outline-none font-bold text-slate-300 font-[Cairo]"
                      >
                        <option value="funny glitches">تجميعات مواقف مضحكة وأخطاء ساخرة (Funnylag Montage)</option>
                        <option value="deep lore and easter eggs">كشف ثغرات وأسرار خفية وغوص قصصي (Deep EasterEggs/Lore)</option>
                        <option value="crazy challenge gameplay">تحديات مجنونة وصعبة جداً باللعب (Impossible Speedrun Specs)</option>
                        <option value="toxic public lobby matches">ردات فعل طريفة في الرومات العامة (Toxic Voicechats Reactions)</option>
                      </select>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-400 font-[Cairo]">اسم اللعبة المرجعية للفيديو:</label>
                      <input 
                        type="text" 
                        value={creatorPreferredGame}
                        onChange={(e) => setCreatorPreferredGame(e.target.value)}
                        placeholder="مثال: Fortnite, Minecraft, FIFA..."
                        className="w-full bg-slate-950/80 text-xs border border-slate-800 focus:border-purple-500/50 px-3.5 py-3 rounded-xl focus:outline-none text-right text-slate-300 font-[Cairo]"
                        required
                      />
                    </div>
                  </div>

                  <div className="flex justify-end pt-3">
                    <button 
                      onClick={handleGenerateContentIdeas}
                      disabled={loadingContent || !creatorPreferredGame}
                      className="inline-flex items-center gap-2 px-7 py-3.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 shadow-lg shadow-purple-500/10 font-bold text-xs text-white transition font-[Cairo] disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {loadingContent ? (
                        <>
                          <RefreshCw className="w-4 h-4 animate-spin" />
                          <span>جاري طبخ السكريبتات وحياكة الأفكار..</span>
                        </>
                      ) : (
                        <>
                          <Video className="w-4 h-4 text-purple-200" />
                          <span>ولّد 5 أفكار مقاطع فيروسية أسطورية</span>
                        </>
                      )}
                    </button>
                  </div>

                  {/* Content suggestions outcome */}
                  {contentIdeas.length > 0 && (
                    <motion.div 
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="space-y-4 pt-4"
                    >
                      <div className="flex items-center justify-between border-t border-slate-900/80 pt-4 flex-row-reverse">
                        <h4 className="text-xs font-mono font-bold text-purple-400 tracking-wider">VIRAL LOOPS VIDEO OUTLINES</h4>
                        <span className="text-[10px] text-slate-500 font-[Tajawal]">انقر لنسخ الموجه الكامل أو العناوين المقترحة للاستعمال</span>
                      </div>

                      <div className="space-y-4">
                        {contentIdeas.map((idea, idx) => (
                          <div 
                            key={idx}
                            className="p-5 bg-slate-950/60 border border-slate-900 rounded-2xl text-right relative group"
                          >
                            <div className="absolute top-4 left-4 opacity-0 group-hover:opacity-100 transition duration-200">
                              <button 
                                onClick={() => handleCopyToClipboard(`العنوان: ${idea.title}\nالافتتاحية: ${idea.hook}\nالسيناريو: ${idea.outline}`)}
                                className="p-1.5 rounded-lg bg-slate-900/85 text-slate-400 hover:text-white"
                                title="Copy full sequence data"
                              >
                                {copiedText && copiedText.includes(idea.title) ? (
                                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                                ) : (
                                  <Copy className="w-3.5 h-3.5" />
                                )}
                              </button>
                            </div>

                            <div className="flex items-center gap-2.5 justify-end flex-row-reverse mb-2">
                              <span className="w-6 h-6 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 font-mono text-xs flex items-center justify-center font-bold">
                                {idx + 1}
                              </span>
                              <h5 className="text-sm font-black text-cyan-300 font-[Cairo]">{idea.title}</h5>
                            </div>

                            <div className="space-y-2 mt-3 text-xs leading-relaxed text-slate-400 font-[Tajawal]">
                              <p>
                                <strong className="text-slate-200">الـ 3 ثواني الأولى (Hook):</strong> {idea.hook}
                              </p>
                              <p>
                                <strong className="text-slate-200">مجرى هيكل المقطع (Story):</strong> {idea.outline}
                              </p>
                              <div className="pt-2 text-[10px] flex gap-3 justify-end text-slate-500 font-mono">
                                <span>Tag: {idea.viralTag}</span>
                                <span>•</span>
                                <span>Background Sound suggestion: {idea.audioAdvise}</span>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </motion.div>
              )}

              {/* Tab 7: Personality test */}
              {activeTab === "personality" && (
                <motion.div
                  key="personality"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-6 relative z-10"
                >
                  <div className="border-b border-slate-900/80 pb-4 text-right">
                    <h2 className="text-xl font-bold font-[Cairo] text-white flex items-center justify-end gap-2.5">
                      <span>مختبر ومحلل شخصية اللاعب السيكولوجي (Cybernetic Gamer Archetype)</span>
                      <span className="text-2xl">🧠</span>
                    </h2>
                    <p className="text-xs text-slate-400 font-[Tajawal] mt-1">اجتز الاختبار الرقمي المكون من 5 معضلات جيمنج معقدة، ودع لوغاريتم الاستدلال يبني غليفك ورادار قوتك الشخصي.</p>
                  </div>

                  {/* 5 Cyber Questionnaires */}
                  <div className="space-y-6 text-right">
                    
                    <div className="p-4 bg-slate-950/60 rounded-2xl border border-slate-900 space-y-2">
                      <span className="text-[10px] font-mono text-purple-400 block font-bold">DILEMMA #1: HANDLING TOXIC CHATS OR PUBLIC DRAMA</span>
                      <p className="text-xs font-bold text-slate-200 font-[Cairo]">1. عند قيام خصم باستفزازك بعبارات سلبية في المحادثة العامة (Chat)، كيف تتصرف عادة؟</p>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-right pt-2">
                        {[
                          "أتجاهله تماماً وأقوم بحظره فوراً للتركيز على المباراة",
                          "أرد عليه بعبارات ساخرة باردة تدمر توازنه النفسي والذهني",
                          "أتشنج أحياناً وأتأثر سلباً وتتشتت دقة لعبي للحظات",
                          "أتوافق مع خويي ونقوم بعمل تكتيك جماعي ترويجي يسكته باللعب"
                        ].map((ans) => (
                          <button 
                            key={ans}
                            onClick={() => {
                              const newAns = [...surveyAnswers];
                              newAns[0] = ans;
                              setSurveyAnswers(newAns);
                            }}
                            className={`p-3 text-right text-xs rounded-xl border font-[Tajawal] transition duration-200 ${
                              surveyAnswers[0] === ans 
                                ? "bg-purple-600/10 border-purple-500 text-purple-200" 
                                : "border-slate-900 bg-slate-950 hover:bg-slate-900/60 text-slate-400"
                            }`}
                          >
                            {ans}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="p-4 bg-slate-950/60 rounded-2xl border border-slate-900 space-y-2">
                      <span className="text-[10px] font-mono text-purple-400 block font-bold">DILEMMA #2: OVERCOOMING EXTREME BOSSES</span>
                      <p className="text-xs font-bold text-slate-200 font-[Cairo]">2. واجهت زعيماً فائق الصعوبة وهزمت للمرة العشرين على التوالي، ما هي ردة فعلك؟</p>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-right pt-2">
                        {[
                          "أحلل تكتيكي وأغير استراتيجيتي وأحاول المحاولة مجدداً بهدوء",
                          "أصرخ غضباً وقد أغلق اللعبة فوراً لتخفيف الضغط العصبي",
                          "أبحث باليوتيوب عن ثغرة برمجية (Glitch) لتخطيه بأقل جهد",
                          "أستمر بنفس الهجوم مع زيادة السرعة متمنياً الحظ هذه المرة"
                        ].map((ans) => (
                          <button 
                            key={ans}
                            onClick={() => {
                              const newAns = [...surveyAnswers];
                              newAns[1] = ans;
                              setSurveyAnswers(newAns);
                            }}
                            className={`p-3 text-right text-xs rounded-xl border font-[Tajawal] transition duration-200 ${
                              surveyAnswers[1] === ans 
                                ? "bg-purple-600/10 border-purple-500 text-purple-200" 
                                : "border-slate-900 bg-slate-950 hover:bg-slate-900/60 text-slate-400"
                            }`}
                          >
                            {ans}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="p-4 bg-slate-950/60 rounded-2xl border border-slate-900 space-y-2">
                      <span className="text-[10px] font-mono text-purple-400 block font-bold">DILEMMA #3: GAME NARRATION CORE VALUE</span>
                      <p className="text-xs font-bold text-slate-200 font-[Cairo]">3. عند اختيار لعبة جديدة للعب، ما هو العنصر الأكثر وزناً وقيمة بالنسبة لك؟</p>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-right pt-2">
                        {[
                          "القصة العميقة والغوص في العالم وتفاصيله والشخصيات",
                          "ميكانيكيات إطلاق النار والحركة فائقة السرعة والتنافس",
                          "الحرية المطلقة للبناء والصناعة والقيادة مع الأصدقاء",
                          "مستوى الصعوبة المتطرف الذي يستحضر أقصى تحدٍ وفخر"
                        ].map((ans) => (
                          <button 
                            key={ans}
                            onClick={() => {
                              const newAns = [...surveyAnswers];
                              newAns[2] = ans;
                              setSurveyAnswers(newAns);
                            }}
                            className={`p-3 text-right text-xs rounded-xl border font-[Tajawal] transition duration-200 ${
                              surveyAnswers[2] === ans 
                                ? "bg-purple-600/10 border-purple-500 text-purple-200" 
                                : "border-slate-900 bg-slate-950 hover:bg-slate-900/60 text-slate-400"
                            }`}
                          >
                            {ans}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="p-4 bg-slate-950/60 rounded-2xl border border-slate-900 space-y-2">
                      <span className="text-[10px] font-mono text-purple-400 block font-bold">DILEMMA #4: 1V5 CLUTCH SCENARIO CHAMPIONS</span>
                      <p className="text-xs font-bold text-slate-200 font-[Cairo]">4. فريقك بالكامل سقط وأنت بموقف (Clutch 1v5) حاسم ببطولة كبرى، ما الذي يدور ببالك؟</p>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-right pt-2">
                        {[
                          "أخطط بهدوء، أترقب حركة الخصم، وأحاول استغلال ميزة المفاجأة",
                          "يصيبني ارتباك شديد كوني محط أنظار الجميع وأفقد التركيز سريعاً",
                          "أندفع بجنون وميكانيكيات عالية لمحاولة القضاء عليهم فرادى بقوة",
                          "أحاول سحب اللعبة للتعادل أو إضاعة الوقت تكتيكياً"
                        ].map((ans) => (
                          <button 
                            key={ans}
                            onClick={() => {
                              const newAns = [...surveyAnswers];
                              newAns[3] = ans;
                              setSurveyAnswers(newAns);
                            }}
                            className={`p-3 text-right text-xs rounded-xl border font-[Tajawal] transition duration-200 ${
                              surveyAnswers[3] === ans 
                                ? "bg-purple-600/10 border-purple-500 text-purple-200" 
                                : "border-slate-900 bg-slate-950 hover:bg-slate-900/60 text-slate-400"
                            }`}
                          >
                            {ans}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="p-4 bg-slate-950/60 rounded-2xl border border-slate-900 space-y-2">
                      <span className="text-[10px] font-mono text-purple-400 block font-bold">DILEMMA #5: MAP BOUNDS AND SECRETS SEEKING</span>
                      <p className="text-xs font-bold text-slate-200 font-[Cairo]">5. عند دخولك خريطة واسعة لأول مرة، هل تذهب مباشرة للمهمة أم تستكشف أطراف الخريطة وثغراتها؟</p>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-right pt-2">
                        {[
                          "أستكشف أدق التفاصيل وأحاول فك الأسرار المخفية",
                          "أنفذ المهمة مباشرة بأقصر الطرق المتاحة لتوفير الوقت",
                          "أبحث عن وحوش اختيارية لرفع لفلي وجمع اللوت الفاخر",
                          "أترقب الأعداء لأصيدهم في الفخاخ عند الأطراف"
                        ].map((ans) => (
                          <button 
                            key={ans}
                            onClick={() => {
                              const newAns = [...surveyAnswers];
                              newAns[4] = ans;
                              setSurveyAnswers(newAns);
                            }}
                            className={`p-3 text-right text-xs rounded-xl border font-[Tajawal] transition duration-200 ${
                              surveyAnswers[4] === ans 
                                ? "bg-purple-600/10 border-purple-500 text-purple-200" 
                                : "border-slate-900 bg-slate-950 hover:bg-slate-900/60 text-slate-400"
                            }`}
                          >
                            {ans}
                          </button>
                        ))}
                      </div>
                    </div>

                  </div>

                  <div className="flex justify-end pt-3">
                    <button 
                      onClick={handleAnalyzePersonality}
                      disabled={loadingSurvey}
                      className="inline-flex items-center gap-2 px-7 py-3.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 shadow-lg shadow-purple-500/10 font-bold text-xs text-white transition font-[Cairo]"
                    >
                      {loadingSurvey ? (
                        <>
                          <RefreshCw className="w-4 h-4 animate-spin" />
                          <span>جاري فك تشفير السلوك وعقد الخلايا الرقمية..</span>
                        </>
                      ) : (
                        <>
                          <Brain className="w-4 h-4 text-purple-200" />
                          <span>حلل شخصيتي التوليدية الآن</span>
                        </>
                      )}
                    </button>
                  </div>

                  {/* Survey diagnostics profile data result */}
                  {surveyResult && (
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.98 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="p-6 bg-slate-950/80 border border-slate-900 rounded-3xl text-right space-y-6 md:p-8"
                    >
                      {/* Identity Card heading */}
                      <div className="flex flex-col md:flex-row-reverse justify-between gap-6 pb-6 border-b border-slate-900">
                        {/* Dynamic Custom Polygon SVG Radar Chart representing player stats */}
                        <div className="w-full md:w-48 h-48 shrink-0 flex items-center justify-center bg-slate-900 border border-slate-900 rounded-2xl relative overflow-hidden">
                          <svg className="w-36 h-36 border border-slate-800 rounded-xl" viewBox="0 0 100 100">
                            {/* Grid circles */}
                            <circle cx="50" cy="50" r="40" fill="none" stroke="#1e293b" strokeWidth="1" strokeDasharray="3 3"/>
                            <circle cx="50" cy="50" r="30" fill="none" stroke="#1e293b" strokeWidth="1"/>
                            <circle cx="50" cy="50" r="20" fill="none" stroke="#1e293b" strokeWidth="1" strokeDasharray="3 3"/>
                            {/* Axis lines */}
                            <line x1="50" y1="10" x2="50" y2="90" stroke="#1e293b" strokeWidth="1"/>
                            <line x1="10" y1="50" x2="90" y2="50" stroke="#1e293b" strokeWidth="1"/>
                            
                            {/* Stats polygon calculated layout */}
                            {(() => {
                              const s = surveyResult.stats || { competitive: 70, lore: 60, mechanics: 80, tactics: 75, chaos: 50 };
                              const rComp = (s.competitive / 100) * 40;
                              const rLore = (s.lore / 100) * 40;
                              const rMech = (s.mechanics / 100) * 40;
                              const rTact = (s.tactics / 100) * 40;
                              const rChaos = (s.chaos / 100) * 40;
                              
                              // Coordinates centering (50, 50)
                              // Angle 1: competitive up (0 degree: 50, 50 - rComp)
                              // Angle 2: lore (72 degrees) -> 50 + rLore * sin(72), 50 - rLore * cos(72)
                              // Angle 3: mechanics (144 degrees)
                              // Angle 4: tactics (216 degrees)
                              // Angle 5: chaos (288 degrees)
                              const p1 = { x: 50, y: 50 - rComp };
                              const p2 = { x: 50 + rLore * 0.95, y: 50 - rLore * 0.31 };
                              const p3 = { x: 50 + rMech * 0.59, y: 50 + rMech * 0.81 };
                              const p4 = { x: 50 - rTact * 0.59, y: 50 + rTact * 0.81 };
                              const p5 = { x: 50 - rChaos * 0.95, y: 50 - rChaos * 0.31 };
                              
                              return (
                                <>
                                  <polygon 
                                    points={`${p1.x},${p1.y} ${p2.x},${p2.y} ${p3.x},${p3.y} ${p4.x},${p4.y} ${p5.x},${p5.y}`}
                                    fill="rgba(168, 85, 247, 0.2)"
                                    stroke="#ec4899"
                                    strokeWidth="1.5"
                                  />
                                  {/* Point descriptors */}
                                  <circle cx={p1.x} cy={p1.y} r="2" fill="#06b6d4" />
                                  <circle cx={p2.x} cy={p2.y} r="2" fill="#06b6d4" />
                                  <circle cx={p3.x} cy={p3.y} r="2" fill="#06b6d4" />
                                  <circle cx={p4.x} cy={p4.y} r="2" fill="#06b6d4" />
                                  <circle cx={p5.x} cy={p5.y} r="2" fill="#06b6d4" />
                                </>
                              );
                            })()}
                          </svg>
                          <div className="absolute bottom-1 bg-black/80 px-2 py-0.5 rounded text-[8px] font-mono text-slate-500">
                            COGNITIVE SPECTRUM DIAL
                          </div>
                        </div>

                        {/* Textual bio details */}
                        <div className="flex-grow space-y-1">
                          <span className="text-[10px] font-mono font-bold text-cyan-400 bg-cyan-400/10 px-2.5 py-1 rounded inline-block uppercase tracking-wider mb-2">
                            {surveyResult.archetypeEnglish || "COGNETIC GAMER"}
                          </span>
                          <h3 className="text-2xl font-black font-[Cairo] text-white">
                            النمط الرقمي: {surveyResult.archetype}
                          </h3>
                          <p className="text-xs text-slate-400 font-[Tajawal] leading-relaxed pt-2">
                            {surveyResult.description}
                          </p>
                        </div>
                      </div>

                      {/* Strengths & Sarcastic Weakness layout */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-right pt-2 text-xs font-[Tajawal]">
                        <div className="p-4 bg-emerald-500/5 border border-emerald-500/10 rounded-2xl">
                          <strong className="text-emerald-400 font-[Cairo] block mb-1">💪 نقاط الميزة المعرفية (Dominant Strengths):</strong>
                          <p className="text-slate-400 leading-relaxed">
                            {surveyResult.strength}
                          </p>
                        </div>

                        <div className="p-4 bg-red-500/5 border border-red-500/10 rounded-2xl">
                          <strong className="text-rose-400 font-[Cairo] block mb-1">☢️ نقطة التحفيز والاستثارة (Critical Weakness):</strong>
                          <p className="text-slate-400 leading-relaxed">
                            {surveyResult.weakness}
                          </p>
                        </div>
                      </div>

                      {/* Multi progressive meters dials for cognitive index */}
                      <div className="space-y-3 pt-2 text-right">
                        <div className="flex justify-between items-center flex-row-reverse text-xs">
                          <span className="font-[Cairo] text-slate-300 font-bold">القدرة والمهارات الذهنية الرقمية:</span>
                          <span className="text-slate-500 font-mono text-[10px]">ANALYSIS SPECTRUM INDEXES</span>
                        </div>
                        
                        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                          {[
                            { label: "الحماسة والتنافس", key: "competitive", color: "bg-purple-500" },
                            { label: "حب القصة والحبكة", key: "lore", color: "bg-pink-500" },
                            { label: "سرعة البديهة والReflex", key: "mechanics", color: "bg-cyan-500" },
                            { label: "التكتيك والذكاء القيادي", key: "tactics", color: "bg-indigo-500" },
                            { label: "مؤشر الفوضى والتلاعب", key: "chaos", color: "bg-red-500" }
                          ].map((statItem) => {
                            const val = surveyResult.stats ? surveyResult.stats[statItem.key] : 70;
                            return (
                              <div key={statItem.key} className="bg-slate-900/60 p-3 rounded-xl border border-slate-900">
                                <span className="text-[10px] text-slate-400 font-[Cairo] block mb-1">{statItem.label}</span>
                                <div className="h-1.5 bg-slate-950 rounded-full overflow-hidden">
                                  <div className={`h-full ${statItem.color}`} style={{ width: `${val}%` }} />
                                </div>
                                <span className="text-xs font-mono font-bold text-slate-200 block mt-1">%{val}</span>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </motion.div>
                  )}
                </motion.div>
              )}

            </AnimatePresence>
          </div>

        </div>

      </div>
    </div>
  );
}
