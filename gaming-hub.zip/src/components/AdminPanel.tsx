/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { PlusCircle, Gamepad2, Gift, Trash2, Edit2, BarChart3, Database, Users, MessageSquare, Image, Calendar, AlertCircle } from "lucide-react";
import { Game, SteamAccount } from "../types";

interface AdminPanelProps {
  games: Game[];
  accounts: SteamAccount[];
  onDataChanged: () => void;
}

export default function AdminPanel({ games, accounts, onDataChanged }: AdminPanelProps) {
  // state metrics
  const [analytics, setAnalytics] = useState({
    totalGames: 0,
    totalAccounts: 0,
    totalPosts: 0,
    activeUsers: 85000,
    interactions: 32000,
    pageViews: 142050
  });

  // Mode trackers
  const [adminTab, setAdminTab] = useState<"analytics" | "games" | "accounts">("analytics");

  // forms: ADD GAME fields
  const [gameTitle, setGameTitle] = useState("");
  const [gameDesc, setGameDesc] = useState("");
  const [gameLongDesc, setGameLongDesc] = useState("");
  const [gamePlatform, setGamePlatform] = useState("Steam");
  const [gameGenre, setGameGenre] = useState("أكشن");
  const [gamePrice, setGamePrice] = useState("39.99");
  const [gameImage, setGameImage] = useState("");
  const [gameBanner, setGameBanner] = useState("");
  const [gameTimerDays, setGameTimerDays] = useState("5");
  const [gameRating, setGameRating] = useState("4.8");
  const [gameError, setGameError] = useState("");
  const [gameSuccess, setGameSuccess] = useState("");

  // forms: ADD ACCOUNT fields
  const [accTitle, setAccTitle] = useState("");
  const [accGamesInline, setAccGamesInline] = useState("");
  const [accEmail, setAccEmail] = useState("");
  const [accPassword, setAccPassword] = useState("");
  const [accNotes, setAccNotes] = useState("");
  const [accImage, setAccImage] = useState("");
  const [accError, setAccError] = useState("");
  const [accSuccess, setAccSuccess] = useState("");

  useEffect(() => {
    fetchAnalytics();
  }, [games, accounts]);

  const fetchAnalytics = async () => {
    try {
      const response = await fetch("/api/analytics");
      if (response.ok) {
        const data = await response.json();
        setAnalytics(data);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleAddGame = async (e: React.FormEvent) => {
    e.preventDefault();
    setGameError("");
    setGameSuccess("");

    if (!gameTitle || !gameDesc) {
      setGameError("يرجى ملء الحقول الإجبارية (العنوان والوصف).");
      return;
    }

    try {
      const days = parseInt(gameTimerDays) || 5;
      const payload = {
        title: gameTitle,
        description: gameDesc,
        longDescription: gameLongDesc || undefined,
        platform: gamePlatform,
        genre: gameGenre,
        originalPrice: parseFloat(gamePrice) || 29.99,
        image: gameImage || "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=800",
        banner: gameBanner || undefined,
        timer: new Date(Date.now() + days * 24 * 60 * 60 * 1000).toISOString(),
        rating: parseFloat(gameRating) || 4.5
      };

      const response = await fetch("/api/games", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      if (response.ok) {
        setGameSuccess("تمت إضافة اللعبة المجانية وتعميمها بنجاح! 🎉");
        // Clear forms
        setGameTitle("");
        setGameDesc("");
        setGameLongDesc("");
        setGameImage("");
        setGameBanner("");
        onDataChanged(); // notify parent to reload lists
      } else {
        throw new Error();
      }
    } catch (e) {
      setGameError("حدث خطأ عند محاولة إرسال البيانات.");
    }
  };

  const handleAddAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    setAccError("");
    setAccSuccess("");

    if (!accTitle || !accEmail || !accPassword) {
      setAccError("الرجاء إدخال بيانات الدخول كاملة مع العنوان.");
      return;
    }

    try {
      const included = accGamesInline.split(",").map((g) => g.trim()).filter(Boolean);
      const payload = {
        title: accTitle,
        email: accEmail,
        password: accPassword,
        notes: accNotes || undefined,
        includedGames: included.length > 0 ? included : ["لعبة ألعاب منوعة"],
        image: accImage || "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?auto=format&fit=crop&q=80&w=400",
        isAvailable: true
      };

      const response = await fetch("/api/steam-accounts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      if (response.ok) {
        setAccSuccess("تم حفظ حساب ستيم وقبول التداول مجاناً! 🎁");
        setAccTitle("");
        setAccEmail("");
        setAccPassword("");
        setAccGamesInline("");
        setAccNotes("");
        setAccImage("");
        onDataChanged();
      } else {
        throw new Error();
      }
    } catch (e) {
      setAccError("خطأ، عذراً لم نستطع حفظ بيانات الحساب.");
    }
  };

  const handleDeleteGame = async (gameId: string) => {
    if (!confirm("هل أنت متأكد من حذف هذا العرض المجاني؟")) return;
    try {
      const response = await fetch(`/api/games/${gameId}`, { method: "DELETE" });
      if (response.ok) {
        onDataChanged();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleDeleteAccount = async (accId: string) => {
    if (!confirm("هل أنت متأكد من سحب هذا الحساب من المستودع؟")) return;
    try {
      const response = await fetch(`/api/steam-accounts/${accId}`, { method: "DELETE" });
      if (response.ok) {
        onDataChanged();
      }
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="w-full min-h-screen py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10" id="admin-panel-root">
      {/* Title */}
      <div className="mb-12 select-none">
        <h2 className="text-3xl font-black font-[Changa] text-transparent bg-clip-text bg-gradient-to-l from-white to-slate-200">
          لوحة تحكّم الإدارة والمشرفين 🛠👑
        </h2>
        <p className="text-slate-400 text-sm mt-1">
          بوابة مراقبة الأداء، وإدراج الألعاب الجديدة في ثوانٍ، وإدارة الحسابات المشتركة.
        </p>
      </div>

      {/* Admin local navigation layout */}
      <div className="flex gap-2 border-b border-slate-900 pb-4 mb-8 select-none">
        <button
          onClick={() => setAdminTab("analytics")}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition ${
            adminTab === "analytics"
              ? "bg-purple-600/10 text-purple-400 border border-purple-500/20"
              : "text-slate-400 hover:text-white"
          }`}
        >
          <BarChart3 className="w-4 h-4" />
          <span>مركز الإحصائيات والأداء</span>
        </button>

        <button
          onClick={() => setAdminTab("games")}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition ${
            adminTab === "games"
              ? "bg-purple-600/10 text-purple-400 border border-purple-500/20"
              : "text-slate-400 hover:text-white"
          }`}
        >
          <Gamepad2 className="w-4 h-4" />
          <span>إدارة العروض والألعاب</span>
        </button>

        <button
          onClick={() => setAdminTab("accounts")}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition ${
            adminTab === "accounts"
              ? "bg-purple-600/10 text-purple-400 border border-purple-500/20"
              : "text-slate-400 hover:text-white"
          }`}
        >
          <Gift className="w-4 h-4" />
          <span>إدارة حسابات ستيم</span>
        </button>
      </div>

      {/* TAB CONTENT: ANALYTICS WIDGETS */}
      {adminTab === "analytics" && (
        <div className="space-y-8 animate-[fadeIn_0.3s_ease]">
          {/* Bento grid indicators */}
          <div className="grid grid-cols-2 lg:grid-cols-3 gap-6 text-right select-none">
            <div className="glass-card p-6 border border-slate-900 rounded-2xl">
              <Database className="w-6 h-6 text-purple-400 mb-3" />
              <div className="text-slate-400 text-[10px] font-bold uppercase">الألعاب على السيرفر</div>
              <div className="text-2xl font-black text-white mt-1">{analytics.totalGames} لعبة نشطة</div>
            </div>

            <div className="glass-card p-6 border border-slate-900 rounded-2xl">
              <Gift className="w-6 h-6 text-indigo-400 mb-3" />
              <div className="text-slate-400 text-[10px] font-bold uppercase">حسابات ستيم المشتركة</div>
              <div className="text-2xl font-black text-white mt-1">{analytics.totalAccounts} حساب مفعل</div>
            </div>

            <div className="glass-card p-6 border border-slate-900 rounded-2xl">
              <Users className="w-6 h-6 text-cyan-400 mb-3" />
              <div className="text-slate-400 text-[10px] font-bold uppercase">التفاعلات الحالية</div>
              <div className="text-2xl font-black text-white mt-1">{(analytics.interactions + analytics.totalPosts).toLocaleString("ar")}+ قراءة</div>
            </div>
          </div>

          {/* Core system report status logs */}
          <div className="p-5 bg-purple-950/20 rounded-2xl border border-purple-500/10 text-right flex gap-3 select-none">
            <AlertCircle className="w-5 h-5 text-purple-400 flex-shrink-0 mt-0.5 animate-pulse" />
            <div>
              <h4 className="text-xs font-bold text-purple-300">تقرير أمان تداول البيانات:</h4>
              <p className="text-slate-400 text-[10px] sm:text-xs leading-relaxed mt-1 font-[Tajawal]">
                جداول الذاكرة في Express Server تعمل وتجاري تحديثات الواجهة بصورة فورية. عند قيامك بإضافة لعبة أو حساب أو نشر ميمز، يتم حفظ البيانات في السيرفر وتعميمها مباشرة لتظهر لجميع زوار موقع Gaming Hub الحقيقيين!
              </p>
            </div>
          </div>
        </div>
      )}

      {/* TAB CONTENT: GAMES MANAGEMENT */}
      {adminTab === "games" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 animate-[fadeIn_0.3s_ease]">
          {/* Creator panel right */}
          <div className="lg:col-span-5 h-fit glass-card p-6 border border-slate-900 rounded-2xl">
            <h3 className="text-base font-bold text-white mb-4 flex items-center gap-1.5 font-[Changa] uppercase">
              <PlusCircle className="w-5 h-5 text-purple-400" />
              <span>أضف لعبة مجانية جديدة:</span>
            </h3>

            <form onSubmit={handleAddGame} className="space-y-4 text-right">
              {gameError && <p className="text-xs text-red-400 font-bold">{gameError}</p>}
              {gameSuccess && <p className="text-xs text-emerald-400 font-bold">{gameSuccess}</p>}

              <div>
                <label className="block text-[10px] text-slate-400 font-bold mb-1">اسم اللعبة الكامل (Title)</label>
                <input
                  type="text"
                  value={gameTitle}
                  onChange={(e) => setGameTitle(e.target.value)}
                  placeholder="مثال: GTA V Premium Edition"
                  className="w-full bg-slate-950 border border-slate-900 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-purple-500 font-semibold"
                  required
                />
              </div>

              <div>
                <label className="block text-[10px] text-slate-400 font-bold mb-1">وصف مختصر للكتالوج (Description)</label>
                <input
                  type="text"
                  value={gameDesc}
                  onChange={(e) => setGameDesc(e.target.value)}
                  placeholder="وصف شيق لبطاقة العرض..."
                  className="w-full bg-slate-950 border border-slate-900 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-purple-500 font-semibold"
                  required
                />
              </div>

              <div>
                <label className="block text-[10px] text-slate-400 font-bold mb-1">تفاصيل الدعم ومتطلبات القصة (Long Description)</label>
                <textarea
                  value={gameLongDesc}
                  onChange={(e) => setGameLongDesc(e.target.value)}
                  placeholder="شرح طويل وممتاز يظهر بالنافذة المنبثقة..."
                  rows={3}
                  className="w-full bg-slate-950 border border-slate-900 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-purple-500 font-semibold"
                ></textarea>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] text-slate-400 font-bold mb-1">المنصة</label>
                  <select
                    value={gamePlatform}
                    onChange={(e) => setGamePlatform(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-900 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none"
                  >
                    <option value="Steam">Steam</option>
                    <option value="Epic Games">Epic Games</option>
                    <option value="Ubisoft Connect">Ubisoft Connect</option>
                    <option value="EA App">EA App</option>
                    <option value="GOG">GOG</option>
                    <option value="Battle.net">Battle.net</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] text-slate-400 font-bold mb-1 font-[Cairo]">العقد والمحور</label>
                  <input
                    type="text"
                    value={gameGenre}
                    onChange={(e) => setGameGenre(e.target.value)}
                    placeholder="أكشن / مغامرات"
                    className="w-full bg-slate-950 border border-slate-900 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none font-semibold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] text-slate-400 font-bold mb-1">السعر الأصلي ($)</label>
                  <input
                    type="text"
                    value={gamePrice}
                    onChange={(e) => setGamePrice(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-900 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none font-semibold"
                  />
                </div>

                <div>
                  <label className="block text-[10px] text-slate-400 font-bold mb-1">صلاحية العرض (أيام)</label>
                  <input
                    type="number"
                    value={gameTimerDays}
                    onChange={(e) => setGameTimerDays(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-900 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none font-semibold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] text-slate-400 font-bold mb-1">صورة الغلاف (Image URL)</label>
                <input
                  type="text"
                  value={gameImage}
                  onChange={(e) => setGameImage(e.target.value)}
                  placeholder="https://images.unsplash.com/photo-..."
                  className="w-full bg-slate-950 border border-slate-900 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none font-mono"
                />
              </div>

              <div>
                <label className="block text-[10px] text-slate-400 font-bold mb-1">صورة البانر الداخلي (Banner URL)</label>
                <input
                  type="text"
                  value={gameBanner}
                  onChange={(e) => setGameBanner(e.target.value)}
                  placeholder="رابط صور بانر طويل..."
                  className="w-full bg-slate-950 border border-slate-900 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none font-mono"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold transition shadow-lg leading-6"
              >
                نشر وتعميم اللعبة الآن 🚀
              </button>
            </form>
          </div>

          {/* Operational list table left */}
          <div className="lg:col-span-7 h-fit glass-card p-6 border border-slate-900 rounded-2xl select-none overscroll-contain">
            <h3 className="text-base font-bold text-white mb-4 font-[Changa]">الألعاب المنشورة حالياً:</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs">
                <thead>
                  <tr className="border-b border-slate-900 text-slate-500">
                    <th className="py-2.5 px-2">اللعبة</th>
                    <th className="py-2.5 px-2">المنصة</th>
                    <th className="py-2.5 px-2">نوع اللعب</th>
                    <th className="py-2.5 px-2">إجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-950">
                  {games.map((g) => (
                    <tr key={g.id} className="hover:bg-slate-900/40 font-[Tajawal]">
                      <td className="py-3 px-2 font-bold text-white truncate max-w-[150px]">{g.title}</td>
                      <td className="py-3 px-2 text-indigo-400">{g.platform}</td>
                      <td className="py-3 px-2 text-slate-400">{g.genre}</td>
                      <td className="py-3 px-2">
                        <button
                          onClick={() => handleDeleteGame(g.id)}
                          className="p-1.5 rounded-lg bg-red-600/10 hover:bg-red-600 text-red-500 hover:text-white transition"
                          title="حذف اللعبة"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB CONTENT: STEAM ACCOUNTS MANAGEMENT */}
      {adminTab === "accounts" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 animate-[fadeIn_0.3s_ease]">
          {/* Creator panel right */}
          <div className="lg:col-span-5 h-fit glass-card p-6 border border-slate-900 rounded-2xl animate-[fadeIn_0.2s_ease]">
            <h3 className="text-base font-bold text-white mb-4 flex items-center gap-1.5 font-[Changa] uppercase">
              <PlusCircle className="w-5 h-5 text-indigo-400" />
              <span>أضف حساب مشترك جديد:</span>
            </h3>

            <form onSubmit={handleAddAccount} className="space-y-4 text-right">
              {accError && <p className="text-xs text-red-400 font-bold">{accError}</p>}
              {accSuccess && <p className="text-xs text-emerald-400 font-bold">{accSuccess}</p>}

              <div>
                <label className="block text-[10px] text-slate-400 font-bold mb-1">اسم العرض للحساب (Title)</label>
                <input
                  type="text"
                  value={accTitle}
                  onChange={(e) => setAccTitle(e.target.value)}
                  placeholder="مثال: حساب ستيم يضم Cyberpunk كاملة"
                  className="w-full bg-slate-950 border border-slate-900 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-indigo-500 font-semibold"
                  required
                />
              </div>

              <div>
                <label className="block text-[10px] text-slate-400 font-bold mb-1">الألعاب المتضمنة (مفصولة بفاصلة)</label>
                <input
                  type="text"
                  value={accGamesInline}
                  onChange={(e) => setAccGamesInline(e.target.value)}
                  placeholder="Cyberpunk 2077, GTA V, Witcher 3"
                  className="w-full bg-slate-950 border border-slate-900 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] text-slate-400 font-bold mb-1">اسم تسجيل الدخول (Email)</label>
                  <input
                    type="text"
                    value={accEmail}
                    onChange={(e) => setAccEmail(e.target.value)}
                    placeholder="vip_account@outlook.com"
                    className="w-full bg-slate-950 border border-slate-900 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none font-mono text-left"
                    required
                  />
                </div>

                <div>
                  <label className="block text-[10px] text-slate-400 font-bold mb-1">كلمة المرور (Password)</label>
                  <input
                    type="text"
                    value={accPassword}
                    onChange={(e) => setAccPassword(e.target.value)}
                    placeholder="VipPassword92!"
                    className="w-full bg-slate-950 border border-slate-900 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none font-mono text-left"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] text-slate-400 font-bold mb-1">ملاحظات ووصية اللعب (Notes)</label>
                <textarea
                  value={accNotes}
                  onChange={(e) => setAccNotes(e.target.value)}
                  placeholder="توصيات الاستخدام كأوفلاين واللعبة أونلاين..."
                  rows={2}
                  className="w-full bg-slate-950 border border-slate-900 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none font-semibold"
                ></textarea>
              </div>

              <div>
                <label className="block text-[10px] text-slate-400 font-bold mb-1">صورة الغلاف للحساب (Image URL)</label>
                <input
                  type="text"
                  value={accImage}
                  onChange={(e) => setAccImage(e.target.value)}
                  placeholder="تضمين رابط صورة دقتها عالية..."
                  className="w-full bg-slate-950 border border-slate-900 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none font-mono"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 text-white rounded-xl text-xs font-bold transition shadow-lg leading-6"
              >
                توليد الحساب بالمستودع 🎁
              </button>
            </form>
          </div>

          {/* Operational list table left */}
          <div className="lg:col-span-7 h-fit glass-card p-6 border border-slate-900 rounded-2xl select-none overscroll-contain">
            <h3 className="text-base font-bold text-white mb-4 font-[Changa]">الحسابات المشتركة حالياً:</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs">
                <thead>
                  <tr className="border-b border-slate-900 text-slate-500">
                    <th className="py-2.5 px-2">الحساب</th>
                    <th className="py-2.5 px-2 font-mono">الإيميل</th>
                    <th className="py-2.5 px-2">الحالة</th>
                    <th className="py-2.5 px-2">إجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-950">
                  {accounts.map((acc) => (
                    <tr key={acc.id} className="hover:bg-slate-900/40 font-[Tajawal]">
                      <td className="py-3 px-2 font-bold text-white truncate max-w-[150px]">{acc.title}</td>
                      <td className="py-3 px-2 text-indigo-400 font-mono text-left select-all">{acc.email}</td>
                      <td className="py-3 px-2">
                        <span className="text-[10px] rounded px-1.5 py-0.5 bg-emerald-500/10 text-emerald-400 font-semibold">متاح</span>
                      </td>
                      <td className="py-3 px-2">
                        <button
                          onClick={() => handleDeleteAccount(acc.id)}
                          className="p-1.5 rounded-lg bg-red-600/10 hover:bg-red-600 text-red-500 hover:text-white transition"
                          title="سحب الحساب"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
