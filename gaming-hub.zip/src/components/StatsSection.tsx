/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from "react";
import { Gamepad2, Users, MessageSquare, Gift } from "lucide-react";

interface StatItemProps {
  icon: React.ReactNode;
  label: string;
  targetNumber: number;
}

function StatItem({ icon, label, targetNumber }: StatItemProps) {
  const [count, setCount] = useState(0);

  useEffect(() => {
    let start = 0;
    const duration = 2000;
    const increment = Math.ceil(targetNumber / (duration / 50));
    const timer = setInterval(() => {
      start += increment;
      if (start >= targetNumber) {
        setCount(targetNumber);
        clearInterval(timer);
      } else {
        setCount(start);
      }
    }, 50);

    return () => clearInterval(timer);
  }, [targetNumber]);

  return (
    <div className="flex flex-col items-center p-6 bg-slate-950/40 backdrop-blur border border-slate-800/40 hover:border-indigo-500/10 rounded-2xl transition duration-300 shadow-xl text-center">
      <div className="w-12 h-12 rounded-xl bg-indigo-500/10 flex items-center justify-center text-indigo-400 mb-4 text-xl">
        {icon}
      </div>
      <div className="text-3xl font-black font-[Cairo] text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-200 to-indigo-400">
        {count.toLocaleString("ar-EG")}+
      </div>
      <div className="text-sm font-semibold text-slate-400 font-[Tajawal] mt-1">{label}</div>
    </div>
  );
}

export default function StatsSection() {
  return (
    <section className="py-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10" id="stats-section">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
        <StatItem icon={<Gamepad2 className="w-6 h-6 text-indigo-400" />} label="ألعاب مجانيّة" targetNumber={1250} />
        <StatItem icon={<Users className="w-6 h-6 text-purple-400" />} label="مستخدِم نشِط" targetNumber={85000} />
        <StatItem icon={<MessageSquare className="w-6 h-6 text-cyan-400" />} label="تعليق وتفاعُل" targetNumber={32000} />
        <StatItem icon={<Gift className="w-6 h-6 text-pink-400" />} label="حساب ستيم مشترك" targetNumber={480} />
      </div>
    </section>
  );
}
