/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { ChevronRight, ChevronLeft, Calendar, ShieldCheck, Flame } from "lucide-react";
import { Game } from "../types";

interface FeaturedSliderProps {
  games: Game[];
  onGameSelect: (game: Game) => void;
}

export default function FeaturedSlider({ games, onGameSelect }: FeaturedSliderProps) {
  const [currentIndex, setCurrentIndex] = useState(0);

  // Filter games with 100% discount
  const featured = games.filter((g) => g.discountPercentage === 100);

  useEffect(() => {
    if (featured.length === 0) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % featured.length);
    }, 6000);
    return () => clearInterval(interval);
  }, [featured]);

  if (featured.length === 0) return null;

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % featured.length);
  };

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + featured.length) % featured.length);
  };

  const currentGame = featured[currentIndex];

  return (
    <section className="py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10" id="featured-slider-section">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end mb-8 gap-4">
        <div>
          <h2 className="text-2xl sm:text-3xl font-extrabold font-[Changa] text-transparent bg-clip-text bg-gradient-to-l from-white to-slate-300 flex items-center gap-2">
            <Flame className="w-6 h-6 text-purple-400 animate-pulse" />
            <span>عروض مجانيّة عاجلة</span>
          </h2>
          <p className="text-slate-400 text-xs sm:text-sm font-[Tajawal] mt-1">
            مجموعة ألعاب مدفوعة بالكامل أصبحت الآن مجانية لوقت محدود! اضغط للمطالبة بخصم 100%
          </p>
        </div>

        {/* Carousel controls */}
        <div className="flex gap-2">
          <button
            onClick={handlePrev}
            className="p-2.5 bg-slate-900 hover:bg-slate-800 border border-slate-800/80 hover:border-slate-700 rounded-xl text-slate-300 hover:text-white transition"
            aria-label="السابق"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
          <button
            onClick={handleNext}
            className="p-2.5 bg-slate-100/10 hover:bg-slate-100/20 border border-slate-800 hover:border-slate-700 rounded-xl text-slate-300 hover:text-white transition"
            aria-label="التالي"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Main Slide Card Container with Glass design */}
      <div className="relative group overflow-hidden glass-card border border-purple-500/20 rounded-3xl transition duration-500 hover:shadow-[0_10px_40px_rgba(168,85,247,0.15)] flex flex-col md:flex-row">
        {/* Banner with absolute gradient overlays */}
        <div className="w-full md:w-3/5 h-64 md:h-[400px] relative overflow-hidden bg-slate-950">
          <img
            src={currentGame.banner || currentGame.image}
            alt={currentGame.title}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
          />
          <div className="absolute inset-0 bg-gradient-to-t md:bg-gradient-to-r from-slate-950 via-slate-950/40 to-transparent"></div>

          {/* Badges */}
          <div className="absolute top-4 right-4 flex flex-col gap-2 z-10">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-purple-600 font-bold text-[10px] sm:text-xs text-white uppercase shadow-lg shadow-purple-500/20">
              {currentGame.platform}
            </span>
          </div>

          <div className="absolute top-4 left-4 z-10">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-600/90 text-[10px] sm:text-xs font-bold text-white shadow-lg animate-pulse">
              عاجل - مجاني 100%
            </span>
          </div>
        </div>

        {/* Info panel */}
        <div className="w-full md:w-2/5 p-6 sm:p-10 flex flex-col justify-between bg-slate-950/90 select-none">
          <div>
            <div className="text-xs font-bold text-indigo-400 mb-2 uppercase font-[Cairo]">
              {currentGame.genre}
            </div>
            <h3 className="text-2xl sm:text-3xl font-black font-[Changa] text-transparent bg-clip-text bg-gradient-to-l from-white to-slate-200 mb-3 leading-tight">
              {currentGame.title}
            </h3>
            <p className="text-slate-400 text-xs sm:text-sm leading-relaxed mb-6 font-[Tajawal]">
              {currentGame.description}
            </p>

            {/* Price values comparison */}
            <div className="flex items-center gap-3 mb-6">
              <span className="text-red-500 line-through text-xs sm:text-sm font-semibold">
                ${currentGame.originalPrice} USD
              </span>
              <span className="text-emerald-400 font-bold text-xl sm:text-2xl font-[Cairo]">
                مجاني بالكامل!
              </span>
              <span className="text-xs font-black bg-emerald-500/10 text-emerald-400 py-1 px-2 border border-emerald-500/30 rounded-lg">
                وفر 100%
              </span>
            </div>

            {/* Timer values indicators */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-slate-900 border border-slate-800 rounded-xl text-xs sm:text-sm font-semibold text-amber-400">
              <Calendar className="w-4 h-4 animate-bounce" />
              <span>العرض ينتهي: {new Date(currentGame.timer).toLocaleDateString("ar-EG")}</span>
            </div>
          </div>

          {/* Call to actions trigger */}
          <div className="mt-8 pt-6 border-t border-slate-900 flex flex-col sm:flex-row gap-3">
            <button
              onClick={() => onGameSelect(currentGame)}
              className="flex-1 text-center py-3.5 px-4 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white rounded-xl text-sm font-bold transition shadow-lg shadow-purple-500/10"
            >
              عرض التفاصيل والمطالبة 📜
            </button>
            <a
              href={currentGame.externalStoreUrl || "https://store.epicgames.com"}
              target="_blank"
              rel="noreferrer"
              className="px-6 py-3.5 bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white rounded-xl text-sm font-semibold text-center transition"
            >
              المتجر الأصلي 🔗
            </a>
          </div>
        </div>
      </div>

      {/* Slide indicators dotted slider */}
      <div className="flex justify-center gap-2 mt-6">
        {featured.map((_, idx) => (
          <button
            key={idx}
            onClick={() => setCurrentIndex(idx)}
            className={`h-2 rounded-full transition-all duration-300 ${
              currentIndex === idx ? "w-8 bg-purple-500" : "w-2 bg-slate-800"
            }`}
          ></button>
        ))}
      </div>
    </section>
  );
}
