/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { KeyRound, ShieldAlert, Sparkles, Copy, Check, Eye } from "lucide-react";
import { SteamAccount } from "../types";

interface SteamAccountsPageProps {
  accounts: SteamAccount[];
}

export default function SteamAccountsPage({ accounts }: SteamAccountsPageProps) {
  const [selectedAccount, setSelectedAccount] = useState<SteamAccount | null>(null);
  const [copiedField, setCopiedField] = useState<"email" | "password" | null>(null);

  const handleCopy = (text: string, field: "email" | "password") => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
  };

  return (
    <div className="w-full min-h-screen py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10" id="steam-accounts-catalog-root">
      {/* Title */}
      <div className="mb-12 select-none">
        <h2 className="text-3xl font-black font-[Changa] text-transparent bg-clip-text bg-gradient-to-l from-white to-slate-200">
          مستودع حسابات ستيم المشتركة
        </h2>
        <p className="text-slate-400 text-sm mt-1">
          وصول مجاني لحسابات ستيم تحتوي على ألعاب باهظة الثمن. يرجى اللغب في وضع أوفلاين (Offline) لحمايتك وسهولة لعب الآخرين.
        </p>
      </div>

      {/* Warning Alert panel */}
      <div className="bg-amber-500/10 border border-amber-500/20 p-5 rounded-2xl mb-10 text-right flex gap-3 select-none">
        <ShieldAlert className="w-6 h-6 text-amber-500 flex-shrink-0 animate-bounce" />
        <div>
          <h4 className="text-xs font-bold text-amber-400 uppercase font-[Cairo] mb-1">تعليمات هامة للاستخدام العادل:</h4>
          <p className="text-slate-400 text-[11px] font-[Tajawal] leading-relaxed">
            1. يرجى <strong>عدم تغيير</strong> أي من بيانات الحساب (الإيميل أو كلمة المرور) حتى لا تفقد الوصول للحساب نهائياً من الحماية المركزية.<br />
            2. يجب الانتقال إلى وضع <strong>Offline Mode</strong> في تطبيق Steam قبل بدء اللعب حتى يتسنى لجميع المشتركين اللعب في نفس الوقت دون تعارض.<br />
            3. استخدام ممتع للجميع! يتم تحديث مستودع الحسابات في مطلع كل أسبوع بواسطة المشرفين.
          </p>
        </div>
      </div>

      {/* Account Grid cards list */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {accounts.map((acc) => (
          <div
            key={acc.id}
            className="group relative glass-card border border-slate-900 hover:border-purple-500/30 rounded-2xl overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:shadow-2xl flex flex-col justify-between"
          >
            <div>
              {/* Cover layout */}
              <div className="aspect-video w-full bg-slate-950 overflow-hidden relative select-none">
                <img
                  src={acc.image}
                  alt={acc.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent"></div>
                <span className={`absolute top-3 right-3 text-[10px] font-bold px-2 py-0.5 rounded ${
                  acc.isAvailable ? "bg-emerald-500/15 text-emerald-400 border border-emerald-500/20" : "bg-red-500/15 text-red-400 border border-red-500/20"
                }`}>
                  {acc.isAvailable ? "● متاح وجاهز" : "● للصيانة"}
                </span>

                <span className="absolute bottom-3 right-3 text-[10px] text-purple-400 bg-purple-500/10 border border-purple-500/20 px-2 py-0.5 rounded font-[Cairo]">
                  أضيف بتاريخ: {acc.dateAdded}
                </span>
              </div>

              {/* Account games summary details */}
              <div className="p-6 space-y-4">
                <h3 className="text-sm sm:text-base font-black text-white group-hover:text-purple-400 transition font-[Cairo] leading-relaxed">
                  {acc.title}
                </h3>

                <div className="space-y-1.5 select-none">
                  <span className="text-[10px] font-bold text-slate-400 block mb-1 font-[Cairo]">أبرز الألعاب المتضمنة بالداخل:</span>
                  <div className="flex flex-wrap gap-1.5">
                    {acc.includedGames.map((game, idx) => (
                      <span key={idx} className="text-[10px] font-semibold text-slate-300 bg-slate-900 border border-slate-800/80 px-2.5 py-1 rounded-lg">
                        {game}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Account card bottom footer action */}
            <div className="p-6 pt-0 mt-4 select-none">
              <button
                onClick={() => setSelectedAccount(acc)}
                className="w-full flex items-center justify-center gap-1.5 py-3 px-4 bg-gradient-to-l from-indigo-950/40 via-indigo-900/10 to-transparent hover:to-indigo-500/20 border border-indigo-500/20 hover:border-indigo-400 rounded-xl text-xs font-bold text-indigo-300 hover:text-white transition shadow-sm leading-6"
              >
                <KeyRound className="w-3.5 h-3.5 text-indigo-400" />
                <span>كشف اسم الحساب وكلمة المرور</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* ACCOUNT DETAILS GLOWING CYBER MODAL POPUP */}
      {selectedAccount && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div
            className="bg-slate-950 border border-slate-800/80 rounded-3xl w-full max-w-md p-6 sm:p-8 shadow-2xl relative select-none animate-[zoomIn_0.3s_ease] border-t-purple-500 border-t-4"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Holographic glowing details */}
            <div className="absolute top-0 right-1/2 translate-x-1/2 -translate-y-1 w-24 h-12 bg-purple-500/20 rounded-full blur-xl pointer-events-none"></div>

            <button
              onClick={() => setSelectedAccount(null)}
              className="absolute top-4 left-4 p-1 rounded-full text-slate-400 hover:text-white transition text-xs font-bold w-7 h-7 flex items-center justify-center border border-slate-800 bg-slate-950"
            >
              ✕
            </button>

            <div className="text-center mb-6">
              <div className="w-12 h-12 bg-purple-500/10 rounded-xl flex items-center justify-center text-purple-400 mx-auto mb-3">
                <KeyRound className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-black text-white font-[Changa]">بيانات حساب ستيم المجاني</h3>
              <p className="text-slate-400 text-xs mt-1 font-[Tajawal]">تأكد من اتباع وضع أوفلاين بعد الدخول مباشرة</p>
            </div>

            {/* Display credentials */}
            <div className="space-y-4 text-right">
              <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 relative">
                <span className="text-[10px] text-slate-400 font-bold block mb-1">اسم المستخدم (Username/Email)</span>
                <div className="flex justify-between items-center bg-slate-950 py-2 px-3 rounded-xl border border-slate-900 mt-1">
                  <span className="text-xs font-semibold text-white select-all font-mono select-text">{selectedAccount.email}</span>
                  <button
                    onClick={() => handleCopy(selectedAccount.email, "email")}
                    className="p-1 px-2.5 rounded bg-purple-600/20 hover:bg-purple-600 border border-purple-500/40 text-[10px] font-bold text-purple-300 hover:text-white transition flex items-center gap-1 leading-5"
                  >
                    {copiedField === "email" ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedField === "email" ? "تم النسخ" : "نسخ"}</span>
                  </button>
                </div>
              </div>

              <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 relative">
                <span className="text-[10px] text-slate-400 font-bold block mb-1">كلمة المرور (Password)</span>
                <div className="flex justify-between items-center bg-slate-950 py-2 px-3 rounded-xl border border-slate-900 mt-1">
                  <span className="text-xs font-semibold text-white select-all font-mono select-text">{selectedAccount.password}</span>
                  <button
                    onClick={() => handleCopy(selectedAccount.password, "password")}
                    className="p-1 px-2.5 rounded bg-purple-600/20 hover:bg-purple-600 border border-purple-500/40 text-[10px] font-bold text-purple-300 hover:text-white transition flex items-center gap-1 leading-5"
                  >
                    {copiedField === "password" ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedField === "password" ? "تم النسخ" : "نسخ"}</span>
                  </button>
                </div>
              </div>

              {selectedAccount.notes && (
                <div className="p-4 bg-purple-950/20 border border-purple-500/10 rounded-2xl text-[10px] text-slate-400 leading-relaxed font-[Tajawal]">
                  <strong className="text-purple-400 block mb-1">توجيه مشرف الحساب:</strong>
                  {selectedAccount.notes}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
