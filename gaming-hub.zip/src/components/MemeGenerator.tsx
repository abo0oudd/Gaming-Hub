/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useState, useEffect } from "react";
import { Upload, Sparkles, Download, Share2, ZoomIn, ZoomOut, RotateCcw, Image as ImageIcon, Type as TypeIcon } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface MemeGeneratorProps {
  onMemeShared?: (imageBase64: string) => void;
}

const TEMPLATES = [
  {
    id: "epic-fail",
    name: "موت مفاجئ باللعبة",
    url: "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=800",
    description: "لاعب مصدوم أمام الشاشة"
  },
  {
    id: "gta-vibe",
    name: "سرقة السيارات الكبرى",
    url: "https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&q=80&w=800",
    description: "قصر فخم وعالم غامض"
  },
  {
    id: "toxic-teammate",
    name: "صراخ وتحدي",
    url: "https://images.unsplash.com/photo-1553481187-be93c21490a9?auto=format&fit=crop&q=80&w=800",
    description: "لاعب غاضب يصرخ على المايك"
  },
  {
    id: "victory-royale",
    name: "انتصار أسطوري",
    url: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&q=80&w=800",
    description: "أضواء سينمائية ونصر ملحمي"
  },
  {
    id: "pc-setup",
    name: "البي سي المحروق",
    url: "https://images.unsplash.com/photo-1587202372775-e229f172b9d7?auto=format&fit=crop&q=80&w=800",
    description: "بي سي أحلام من كرتون وسلوك متقاطعة"
  }
];

export default function MemeGenerator({ onMemeShared }: MemeGeneratorProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [topText, setTopText] = useState("شكل البي سي مالي");
  const [bottomText, setBottomText] = useState("لما أشغل لعبة دقتها 4K");
  const [selectedImage, setSelectedImage] = useState<string>(TEMPLATES[0].url);
  const [fontSize, setFontSize] = useState<number>(36);
  const [textColor, setTextColor] = useState<string>("#FFFFFF");
  const [strokeColor, setStrokeColor] = useState<string>("#000000");
  const [textPosition, setTextPosition] = useState<{ topY: number; bottomY: number }>({ topY: 15, bottomY: 85 });
  const [magicCaptions, setMagicCaptions] = useState<string[]>([]);
  const [isLoadingCaptions, setIsLoadingCaptions] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string>("");
  const [isScanning, setIsScanning] = useState<boolean>(false);

  // Redraw canvas whenever parameters change
  useEffect(() => {
    drawMeme();
  }, [topText, bottomText, selectedImage, fontSize, textColor, strokeColor, textPosition]);

  const drawMeme = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const img = new Image();
    img.crossOrigin = "anonymous";
    img.src = selectedImage;
    img.onload = () => {
      // Set canvas size to match image layout (bounded by standard sizing)
      const maxDim = 600;
      let w = img.width;
      let h = img.height;

      if (w > maxDim || h > maxDim) {
        if (w > h) {
          h = Math.round((h * maxDim) / w);
          w = maxDim;
        } else {
          w = Math.round((w * maxDim) / h);
          h = maxDim;
        }
      }

      canvas.width = w;
      canvas.height = h;

      // Draw original image
      ctx.drawImage(img, 0, 0, w, h);

      // Apply impact style for memes
      ctx.fillStyle = textColor;
      ctx.strokeStyle = strokeColor;
      ctx.lineWidth = Math.max(1, Math.round(fontSize / 6));
      ctx.lineJoin = "miter";
      ctx.miterLimit = 2;
      ctx.font = `bold ${fontSize}px "Cairo", "Changa", Impact, sans-serif`;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";

      // Draw Top Text
      if (topText) {
        const topYCoord = (textPosition.topY / 100) * h;
        // Wrap text to avoid overflow
        wrapText(ctx, topText.toUpperCase(), w / 2, topYCoord, w - 40, fontSize * 1.2, true);
      }

      // Draw Bottom Text
      if (bottomText) {
        const bottomYCoord = (textPosition.bottomY / 100) * h;
        wrapText(ctx, bottomText.toUpperCase(), w / 2, bottomYCoord, w - 40, fontSize * 1.2, true);
      }
    };
  };

  // Helper to wrap text nicely on canvas
  const wrapText = (
    ctx: CanvasRenderingContext2D,
    text: string,
    x: number,
    y: number,
    maxWidth: number,
    lineHeight: number,
    stroke: boolean
  ) => {
    const words = text.split(" ");
    let line = "";
    const lines = [];

    for (let n = 0; n < words.length; n++) {
      const testLine = line + words[n] + " ";
      const metrics = ctx.measureText(testLine);
      const testWidth = metrics.width;
      if (testWidth > maxWidth && n > 0) {
        lines.push(line);
        line = words[n] + " ";
      } else {
        line = testLine;
      }
    }
    lines.push(line);

    // Adjust start Y based on number of lines to center vertically on the line
    const startY = y - ((lines.length - 1) * lineHeight) / 2;

    for (let k = 0; k < lines.length; k++) {
      const currentY = startY + k * lineHeight;
      if (stroke) {
        ctx.strokeText(lines[k].trim(), x, currentY);
      }
      ctx.fillText(lines[k].trim(), x, currentY);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        setSelectedImage(event.target.result as string);
        setMagicCaptions([]); // clear stale captions
        setErrorMessage("");
      }
    };
    reader.readAsDataURL(file);
  };

  // AI MAGIC CAPTION CALL (Express full-stack backend handles Gemini)
  const generateMagicCaptions = async () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    try {
      setIsLoadingCaptions(true);
      setIsScanning(true);
      setErrorMessage("");

      // Convert canvas to base64
      let dataUrl = canvas.toDataURL("image/jpeg", 0.85);
      const base64Content = dataUrl.split(",")[1];

      const response = await fetch("/api/magic-caption", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          imageBase64: base64Content,
          mimeType: "image/jpeg",
          description: "صورة ميم ألعاب عربي قيد التصميم للتسلية والضحك الساخر"
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "خطأ أثناء توليد الكابشن بلغة الذكاء الاصطناعي.");
      }

      const data = await response.json();
      if (data.captions && Array.isArray(data.captions)) {
        setMagicCaptions(data.captions);
      } else {
        throw new Error("تنسيق رد غير متوقع من الخادم.");
      }
    } catch (err: any) {
      console.error(err);
      setErrorMessage(err.message || "فشل توليد الكابشن الذكي، تأكد من إدخال مفتاح API في الخزنة.");
    } finally {
      setIsLoadingCaptions(false);
      setIsScanning(false);
    }
  };

  // Apply caption selection
  const handleCaptionSelect = (caption: string) => {
    // If caption has a structure like "لما..." split at midpoint or just put it at bottom
    if (caption.includes("لما") && caption.length > 20) {
      const mid = Math.floor(caption.length / 2);
      const splitIndex = caption.indexOf(" ", mid);
      if (splitIndex !== -1) {
        setTopText(caption.substring(0, splitIndex).trim());
        setBottomText(caption.substring(splitIndex).trim());
        return;
      }
    }
    setTopText("شكلي لما:");
    setBottomText(caption);
  };

  const handleDownload = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const dataUrl = canvas.toDataURL("image/jpeg", 0.95);
    const link = document.createElement("a");
    link.download = `gaming-hub-meme-${Date.now()}.jpg`;
    link.href = dataUrl;
    link.click();
  };

  const handleShareToCommunity = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const dataUrl = canvas.toDataURL("image/jpeg", 0.85);
    if (onMemeShared) {
      onMemeShared(dataUrl);
    }
  };

  return (
    <div className="w-full max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8 py-4 px-2 select-none" id="meme-generator-root">
      {/* Options Panel (Left/RTL-Right) */}
      <div className="lg:col-span-5 flex flex-col gap-6 order-2 lg:order-1">
        {/* Templates selector */}
        <div className="glass-card p-6 border border-purple-500/20 rounded-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-24 h-24 bg-purple-500/10 rounded-full blur-2xl pointer-events-none"></div>
          <h3 className="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-l from-violet-400 to-indigo-400 mb-4 flex items-center gap-2">
            <ImageIcon className="w-5 h-5 text-purple-400" />
            <span>اختر قالب الميمز الشائع</span>
          </h3>
          <div className="grid grid-cols-5 gap-2">
            {TEMPLATES.map((tmpl) => (
              <button
                key={tmpl.id}
                onClick={() => {
                  setSelectedImage(tmpl.url);
                  setMagicCaptions([]);
                }}
                className={`group relative aspect-square rounded-xl overflow-hidden bg-slate-900 border-2 transition-all ${
                  selectedImage === tmpl.url ? "border-purple-500 scale-95 shadow-cyan-500/20 shadow-lg" : "border-slate-800 hover:border-slate-700"
                }`}
                title={tmpl.name}
              >
                <img
                  src={tmpl.url}
                  alt={tmpl.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end justify-center p-1">
                  <span className="text-[10px] font-bold text-white truncate w-full text-center">{tmpl.name}</span>
                </div>
              </button>
            ))}
          </div>

          <div className="mt-4">
            <div className="relative">
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleImageUpload}
                accept="image/*"
                className="hidden"
                id="meme-image-upload"
              />
              <button
                onClick={() => fileInputRef.current?.click()}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-slate-900/60 hover:bg-slate-900/80 border-2 border-dashed border-purple-500/30 hover:border-purple-500/60 rounded-xl cursor-pointer text-sm font-semibold text-slate-300 transition-all"
              >
                <Upload className="w-4 h-4 text-purple-400" />
                <span>تحميل صورة خاصة من جهازك</span>
              </button>
            </div>
          </div>
        </div>

        {/* Text Configuration Customizer */}
        <div className="glass-card p-6 border border-purple-500/20 rounded-2xl">
          <h3 className="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-l from-violet-400 to-indigo-400 mb-4 flex items-center gap-2">
            <TypeIcon className="w-5 h-5 text-indigo-400" />
            <span>تخصيص نصوص الميمز</span>
          </h3>

          <div className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-2">النص العلوي</label>
              <input
                type="text"
                value={topText}
                onChange={(e) => setTopText(e.target.value)}
                className="w-full bg-slate-950/80 border border-slate-800 focus:border-purple-500 rounded-xl px-4 py-3 text-sm text-white focus:outline-none transition-all font-semibold"
                placeholder="اكتب شيئاً هنا..."
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-2">النص السفلي</label>
              <input
                type="text"
                value={bottomText}
                onChange={(e) => setBottomText(e.target.value)}
                className="w-full bg-slate-950/80 border border-slate-800 focus:border-purple-500 rounded-xl px-4 py-3 text-sm text-white focus:outline-none transition-all font-semibold"
                placeholder="شكل اللعبة لما تشتغل..."
              />
            </div>

            <div className="grid grid-cols-2 gap-4 pt-2">
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-2">حجم الخط</label>
                <div className="flex gap-2 items-center">
                  <button
                    onClick={() => setFontSize(prev => Math.max(16, prev - 4))}
                    className="p-2 bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-lg text-slate-300"
                  >
                    <ZoomOut className="w-4 h-4" />
                  </button>
                  <span className="text-sm font-bold text-white w-12 text-center">{fontSize}px</span>
                  <button
                    onClick={() => setFontSize(prev => Math.min(80, prev + 4))}
                    className="p-2 bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-lg text-slate-300"
                  >
                    <ZoomIn className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-2">لون الخط والمحيط</label>
                <div className="flex gap-3 mt-1">
                  <div className="flex flex-col items-center gap-1">
                    <input
                      type="color"
                      value={textColor}
                      onChange={(e) => setTextColor(e.target.value)}
                      className="w-8 h-8 rounded cursor-pointer border-0 p-0 overflow-hidden bg-transparent"
                    />
                    <span className="text-[10px] text-slate-400">الداخل</span>
                  </div>
                  <div className="flex flex-col items-center gap-1">
                    <input
                      type="color"
                      value={strokeColor}
                      onChange={(e) => setStrokeColor(e.target.value)}
                      className="w-8 h-8 rounded cursor-pointer border-0 p-0 overflow-hidden bg-transparent"
                    />
                    <span className="text-[10px] text-slate-400">الإطار</span>
                  </div>
                  <button
                    onClick={() => {
                      setTextColor("#FFFFFF");
                      setStrokeColor("#000000");
                      setFontSize(36);
                      setTextPosition({ topY: 15, bottomY: 85 });
                    }}
                    className="p-2 bg-slate-900 border border-slate-800 hover:border-slate-600 rounded-lg text-slate-300 flex items-center justify-center self-center"
                    title="إعادة تعيين الخطوط"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>

            {/* Vertically sliding modifiers */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">موضع النص العلوي (Y)</label>
                <input
                  type="range"
                  min="5"
                  max="45"
                  value={textPosition.topY}
                  onChange={(e) => setTextPosition(prev => ({ ...prev, topY: parseInt(e.target.value) }))}
                  className="w-full accent-purple-500 h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">موضع النص السفلي (Y)</label>
                <input
                  type="range"
                  min="55"
                  max="95"
                  value={textPosition.bottomY}
                  onChange={(e) => setTextPosition(prev => ({ ...prev, bottomY: parseInt(e.target.value) }))}
                  className="w-full accent-purple-500 h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Editor & Preview Area (Right/RTL-Left) */}
      <div className="lg:col-span-7 flex flex-col gap-6 order-1 lg:order-2">
        {/* Interactive Canvas Board */}
        <div className="glass-card p-6 border border-cyan-500/20 rounded-3xl flex flex-col items-center justify-center bg-slate-900/40 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-24 h-24 bg-cyan-500/10 rounded-full blur-2xl pointer-events-none"></div>

          {/* Glowing Scanning line while AI runs */}
          {isScanning && (
            <div className="absolute inset-x-0 h-1 bg-cyan-500 shadow-[0_0_15px_#22d3ee] z-20 animate-bounce top-0 pointer-events-none" style={{ animationDuration: "3s" }}></div>
          )}

          <div className="text-center w-full mb-3 flex justify-between items-center px-2">
            <span className="text-xs font-semibold tracking-wider text-cyan-400 flex items-center gap-1.5 uppercase">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse"></span>
              مساحة تحرير الصورة والتحكم
            </span>
            <button
              onClick={() => {
                setTopText("");
                setBottomText("");
              }}
              className="text-[10px] text-slate-400 hover:text-white underline transition"
            >
              مسح النصوص بالكامل
            </button>
          </div>

          <div className="relative max-w-full overflow-auto bg-slate-950 p-2 rounded-2xl border border-slate-800/80 shadow-2xl flex items-center justify-center min-h-[300px]">
            <canvas
              ref={canvasRef}
              className="mx-auto rounded-lg max-w-full object-contain shadow-2xl transition"
            />
          </div>

          {/* Big action triggers */}
          <div className="w-full grid grid-cols-1 sm:grid-cols-3 gap-3 mt-6">
            <button
              onClick={generateMagicCaptions}
              disabled={isLoadingCaptions}
              className={`sm:col-span-1 group relative flex items-center justify-center gap-1.5 py-3 px-4 rounded-xl font-bold text-sm select-none transition-all duration-300 bg-gradient-to-r from-purple-600 via-indigo-600 to-cyan-600 hover:from-purple-500 hover:to-cyan-500 text-white shadow-lg overflow-hidden ${
                isLoadingCaptions ? "opacity-75 cursor-wait" : ""
              }`}
            >
              <Sparkles className={`w-4 h-4 text-yellow-300 ${isLoadingCaptions ? "animate-spin" : "group-hover:animate-bounce"}`} />
              <span>{isLoadingCaptions ? "جاري التحليل... ⚡" : "كابشن سحري بالذكاء ⚡"}</span>
            </button>

            <button
              onClick={handleDownload}
              className="group flex items-center justify-center gap-1.5 py-3 px-4 bg-slate-900 border border-slate-800 hover:border-slate-700 hover:bg-slate-950 text-slate-200 hover:text-white rounded-xl text-sm font-semibold transition"
            >
              <Download className="w-4 h-4 text-cyan-400 group-hover:translate-y-0.5 transition-transform" />
              <span>حفظ الصورة 📥</span>
            </button>

            <button
              onClick={handleShareToCommunity}
              className="group flex items-center justify-center gap-1.5 py-3 px-4 bg-[#7289da]/80 hover:bg-[#7289da] text-white rounded-xl text-sm font-strong transition shadow-md"
            >
              <Share2 className="w-4 h-4 group-hover:scale-110 transition-transform" />
              <span>نشر في المجتمع 📢</span>
            </button>
          </div>
        </div>

        {/* Suggested Captions from AI model */}
        <AnimatePresence mode="popLayout">
          {(magicCaptions.length > 0 || isLoadingCaptions || errorMessage) && (
            <motion.div
              layout
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="glass-card p-6 border border-purple-500/20 rounded-2xl bg-gradient-to-br from-indigo-950/20 to-purple-950/20 relative"
            >
              <h4 className="text-base font-bold text-slate-300 mb-3 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-yellow-300 animate-pulse" />
                <span>عناوين مقترحة بالذكاء الاصطناعي (انقر للتطبيق):</span>
              </h4>

              {errorMessage && (
                <div className="bg-red-500/10 border border-red-500/30 rounded-xl px-4 py-3 text-xs text-red-400 mt-2">
                  {errorMessage}
                </div>
              )}

              {isLoadingCaptions ? (
                <div className="space-y-2 mt-2">
                  {[1, 2, 3].map((idx) => (
                    <div key={idx} className="w-full h-10 bg-slate-800/40 rounded-xl animate-pulse"></div>
                  ))}
                  <div className="text-center text-[10px] text-slate-500 animate-pulse mt-2">
                    يرجى الانتظار، يقوم الذكاء الاصطناعي بتحليل الألوان والوجوه والتعبيرات...
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-2 mt-2">
                  {magicCaptions.map((caption, idx) => (
                    <motion.button
                      key={idx}
                      whileHover={{ scale: 1.01, x: -3 }}
                      whileTap={{ scale: 0.99 }}
                      onClick={() => handleCaptionSelect(caption)}
                      className="w-full text-right text-xs py-3 px-4 bg-slate-950/60 hover:bg-purple-950/40 border border-slate-800 hover:border-purple-500/40 rounded-xl text-slate-300 hover:text-white font-semibold transition"
                    >
                      {caption}
                    </motion.button>
                  ))}
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
