/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { MessageSquare, ThumbsUp, ThumbsDown, MessageCircle, RefreshCw, Send, PlusCircle, Sparkles, Image as ImageIcon } from "lucide-react";
import { Post, CommunityComment } from "../types";
import MemeGenerator from "./MemeGenerator";
import { motion, AnimatePresence } from "motion/react";

interface CommunityPageProps {
  posts: Post[];
  onPostCreated?: () => void;
}

export default function CommunityPage({ posts: initialPosts, onPostCreated }: CommunityPageProps) {
  const [posts, setPosts] = useState<Post[]>(initialPosts);
  const [activeTab, setActiveTab] = useState<"showroom" | "meme">("showroom");

  // forum creation fields
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [userName, setUserName] = useState("");
  const [isCreating, setIsCreating] = useState(false);

  // reply field trackers (mapped by post.id)
  const [commentInputs, setCommentInputs] = useState<{ [postId: string]: string }>({});

  useEffect(() => {
    setPosts(initialPosts);
  }, [initialPosts]);

  const handleCreatePost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) return;

    try {
      const uName = userName.trim() || "صاحب_الميمز";
      const payload = {
        title: title.trim() || undefined,
        content: content.trim(),
        image: imageUrl.trim() || undefined,
        username: uName
      };

      const response = await fetch("/api/posts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      if (response.ok) {
        setTitle("");
        setContent("");
        setImageUrl("");
        setUserName("");
        setIsCreating(false);
        if (onPostCreated) onPostCreated(); // trigger main state refetch
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Callback from MemeGenerator: user created a meme and wants to publish it to forum!
  const handleMemeSharedToForum = async (imageBase64: string) => {
    try {
      const payload = {
        title: "صمم ميمز أسطوري بالذكاء الاصطناعي!",
        content: "شوفوا الميمز الرهيب اللي صنعته تواً باستخدام مولّد الميمز بالذكاء الاصطناعي في جوردن جيمينج هاب! جربوه بموقعنا واكشفوا الكابشن السحري",
        image: imageBase64,
        username: "عبقري_الميمز"
      };

      const response = await fetch("/api/posts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      if (response.ok) {
        if (onPostCreated) onPostCreated(); // reload posts
        setActiveTab("showroom"); // jump to showroom to show it!
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleLike = async (postId: string) => {
    try {
      const response = await fetch(`/api/posts/${postId}/like`, { method: "POST" });
      if (response.ok) {
        setPosts((prev) =>
          prev.map((p) => (p.id === postId ? { ...p, likes: p.likes + 1, likedByUser: true } : p))
        );
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleDislike = async (postId: string) => {
    try {
      const response = await fetch(`/api/posts/${postId}/dislike`, { method: "POST" });
      if (response.ok) {
        setPosts((prev) =>
          prev.map((p) => (p.id === postId ? { ...p, dislikes: p.dislikes + 1, dislikedByUser: true } : p))
        );
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handlePostComment = async (postId: string, e: React.FormEvent) => {
    e.preventDefault();
    const commentContent = commentInputs[postId];
    if (!commentContent || !commentContent.trim()) return;

    try {
      const response = await fetch(`/api/posts/${postId}/comments`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: "جيمر_تفاعل",
          content: commentContent.trim()
        })
      });

      if (response.ok) {
        const newCom: CommunityComment = await response.json();
        setPosts((prev) =>
          prev.map((p) => {
            if (p.id === postId) {
              return { ...p, comments: [...p.comments, newCom] };
            }
            return p;
          })
        );
        setCommentInputs((prev) => ({ ...prev, [postId]: "" }));
        if (onPostCreated) onPostCreated();
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="w-full min-h-screen py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10" id="community-hub-root">
      {/* Title */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end mb-12 gap-4 select-none">
        <div>
          <h2 className="text-3xl font-black font-[Changa] text-transparent bg-clip-text bg-gradient-to-l from-white to-slate-200">
            ملتقى اللاعبين وصناعة الميمز
          </h2>
          <p className="text-slate-400 text-sm mt-1">تفاعل مع اللاعبين، شارك لقطات مضحكة، أو صمم ميمز بالذكاء الاصطناعي وانشرها مباشرة!</p>
        </div>

        {/* Tab Selection */}
        <div className="flex gap-2 p-1 bg-slate-950 border border-slate-900 rounded-2xl">
          <button
            onClick={() => setActiveTab("showroom")}
            className={`px-5 py-2 rounded-xl text-xs font-bold transition ${
              activeTab === "showroom"
                ? "bg-purple-600 text-white shadow-md shadow-purple-500/10"
                : "text-slate-400 hover:text-white"
            }`}
          >
            منشورات المجتمع
          </button>
          <button
            onClick={() => setActiveTab("meme")}
            className={`px-5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
              activeTab === "meme"
                ? "bg-purple-600 text-white shadow-md shadow-purple-500/10"
                : "text-slate-400 hover:text-white"
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-yellow-300 animate-pulse" />
            <span>صانع الميمز الذكي</span>
          </button>
        </div>
      </div>

      {/* RENDER ACTIVE TAB */}
      {activeTab === "meme" ? (
        <motion.div
          key="meme-generator-view"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <div className="text-center max-w-2xl mx-auto mb-8 select-none">
            <span className="text-xs bg-purple-500/10 border border-purple-500/20 py-1.5 px-3 rounded-full font-bold text-purple-400 font-[Cairo] inline-block mb-3">
              محرك دمج النماذج مع Gemini 3.5 Flash
            </span>
            <p className="text-slate-300 text-sm font-[Tajawal] leading-relaxed">
              ارفع صورة أو اختر قالب ميمز ألعاب شهير، واضغط على زر <strong className="text-purple-400">"كابشن سحري"</strong> ليقوم الذكاء الاصطناعي برصد وتحليل الصورة واقتراح 5 عناوين مضحكة في ثوانٍ!
            </p>
          </div>
          <MemeGenerator onMemeShared={handleMemeSharedToForum} />
        </motion.div>
      ) : (
        <motion.div
          key="showroom-discussion-view"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="grid grid-cols-1 lg:grid-cols-12 gap-8"
        >
          {/* Forum Streams Left */}
          <div className="lg:col-span-8 space-y-6">
            {posts.length > 0 ? (
              posts.map((post) => (
                <div key={post.id} className="glass-card p-6 border border-slate-900 rounded-2xl space-y-4">
                  {/* User Profile Info */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <img
                        src={post.avatar}
                        alt={post.username}
                        className="w-10 h-10 rounded-full bg-slate-900 border border-slate-800"
                      />
                      <div>
                        <h4 className="text-sm font-bold text-white font-[Cairo]">{post.username}</h4>
                        <span className="text-[10px] text-slate-500 block">{post.date}</span>
                      </div>
                    </div>
                  </div>

                  {/* Message body */}
                  <div className="space-y-3">
                    {post.title && (
                      <h3 className="text-base font-black text-transparent bg-clip-text bg-gradient-to-l from-white to-slate-200 font-[Cairo]">
                        {post.title}
                      </h3>
                    )}
                    <p className="text-slate-300 text-xs sm:text-sm font-[Tajawal] leading-relaxed whitespace-pre-wrap">{post.content}</p>
                    {post.image && (
                      <div className="rounded-xl overflow-hidden max-h-[400px] border border-slate-900 bg-slate-950 flex items-center justify-center p-1">
                        <img
                          src={post.image}
                          alt="صورة ميم جدار"
                          referrerPolicy="no-referrer"
                          className="max-h-[385px] rounded-lg w-auto object-contain shadow-md"
                        />
                      </div>
                    )}
                  </div>

                  {/* Likes / commenting actions */}
                  <div className="flex gap-4 items-center pt-2 border-t border-slate-950 text-slate-400 select-none">
                    <button
                      onClick={() => handleLike(post.id)}
                      disabled={post.likedByUser}
                      className={`flex items-center gap-1.5 text-xs font-semibold ${
                        post.likedByUser ? "text-indigo-400" : "hover:text-white"
                      }`}
                    >
                      <ThumbsUp className="w-4 h-4" />
                      <span>{post.likes}</span>
                    </button>

                    <button
                      onClick={() => handleDislike(post.id)}
                      disabled={post.dislikedByUser}
                      className={`flex items-center gap-1.5 text-xs font-semibold ${
                        post.dislikedByUser ? "text-red-400" : "hover:text-white"
                      }`}
                    >
                      <ThumbsDown className="w-4 h-4" />
                      <span>{post.dislikes}</span>
                    </button>

                    <span className="flex items-center gap-1.5 text-xs text-slate-400 font-semibold ms-auto">
                      <MessageCircle className="w-4 h-4" />
                      <span>{post.comments.length} تعليق</span>
                    </span>
                  </div>

                  {/* Comment Threading List */}
                  {post.comments.length > 0 && (
                    <div className="space-y-2.5 pl-0 pr-4 sm:pr-6 border-r-2 border-slate-900 mt-4">
                      {post.comments.map((comment) => (
                        <div key={comment.id} className="text-right flex gap-3 p-3 bg-slate-950/40 rounded-xl border border-slate-900/60">
                          <img src={comment.avatar} alt="ملعق" className="w-7 h-7 rounded-full bg-slate-900" />
                          <div>
                            <div className="flex items-center gap-2 mb-0.5">
                              <span className="text-[11px] font-bold text-white font-[Cairo]">{comment.username}</span>
                              <span className="text-[9px] text-slate-500">{comment.date}</span>
                            </div>
                            <p className="text-[11px] text-slate-300 font-[Tajawal] leading-relaxed">{comment.content}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Push Reply Field */}
                  <form onSubmit={(e) => handlePostComment(post.id, e)} className="flex items-center gap-2 mt-4">
                    <input
                      type="text"
                      value={commentInputs[post.id] || ""}
                      onChange={(e) => setCommentInputs({ ...commentInputs, [post.id]: e.target.value })}
                      placeholder="اكتب تعليقاً على هذا المقال..."
                      className="flex-1 bg-slate-950 border border-slate-900 text-xs rounded-xl px-4 py-2.5 text-white placeholder-slate-600 focus:outline-none focus:border-purple-500/50 transition-all font-semibold"
                    />
                    <button type="submit" className="p-2.5 bg-purple-600 hover:bg-purple-500 text-white rounded-xl transition">
                      <Send className="w-3.5 h-3.5" />
                    </button>
                  </form>
                </div>
              ))
            ) : (
              <div className="text-center py-24 glass-card select-none">
                <span className="text-4xl text-slate-500">💬</span>
                <h3 className="text-base font-bold text-slate-300 mt-4">لا توجد محادثات نشطة بعد</h3>
                <p className="text-slate-500 text-xs mt-1">ابدأ بكتابة أول مشاركة لتبادل الأفكار مع لاعبيك!</p>
              </div>
            )}
          </div>

          {/* New Post Creator sidebar Panel Right */}
          <div className="lg:col-span-4 space-y-6">
            <div className="glass-card p-6 border border-slate-900 rounded-2xl relative overflow-hidden">
              <div className="absolute top-0 left-0 w-24 h-24 bg-purple-500/5 rounded-full blur-2xl pointer-events-none"></div>

              <h3 className="text-lg font-black font-[Cairo] text-transparent bg-clip-text bg-gradient-to-l from-white to-slate-200 mb-4 flex items-center gap-2">
                <PlusCircle className="w-5 h-5 text-purple-400" />
                <span>إضافة موضوع جديد</span>
              </h3>

              <form onSubmit={handleCreatePost} className="space-y-4 text-right">
                <div>
                  <label className="block text-[10px] text-slate-400 font-bold mb-2">اسمك المستعار</label>
                  <input
                    type="text"
                    value={userName}
                    onChange={(e) => setUserName(e.target.value)}
                    placeholder="مثل: صقر_الجيمينج"
                    className="w-full bg-slate-950 border border-slate-900 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-purple-500 transition font-semibold"
                  />
                </div>

                <div>
                  <label className="block text-[10px] text-slate-400 font-bold mb-2">عنوان قصير</label>
                  <input
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="مثل: رأيكم في لعبة مارفل الجديدة؟"
                    className="w-full bg-slate-950 border border-slate-900 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-purple-500 transition font-semibold"
                  />
                </div>

                <div>
                  <label className="block text-[10px] text-slate-400 font-bold mb-2">محتوى الإدراج</label>
                  <textarea
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    placeholder="شارك بنصائح، ميمات، لقطات شاشة، آراء، وتفاعل مع الآخرين بروح رياضية..."
                    rows={4}
                    className="w-full bg-slate-950 border border-slate-900 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-purple-500 transition font-semibold"
                    required
                  ></textarea>
                </div>

                <div>
                  <label className="block text-[10px] text-slate-400 font-bold mb-2">رابط صورة (اختياري)</label>
                  <input
                    type="text"
                    value={imageUrl}
                    onChange={(e) => setImageUrl(e.target.value)}
                    placeholder="https://example.com/meme.jpg"
                    className="w-full bg-slate-950 border border-slate-900 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-purple-500 transition font-semibold"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold transition shadow-lg shadow-purple-500/10 leading-6"
                >
                  نشر المنشور الآن 🚀
                </button>
              </form>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
}
