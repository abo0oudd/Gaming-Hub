/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Star, Gamepad2 } from "lucide-react";

interface TrendingGame {
  id: string;
  title: string;
  genre: string;
  rating: number;
  image: string;
  platform: string;
  description: string;
}

const TRENDING_MOCK: TrendingGame[] = [
  {
    id: "pubg-m",
    title: "PUBG: Battlegrounds",
    genre: "باتل رويال / تصويب",
    rating: 4.8,
    image: "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=600",
    platform: "Steam",
    description: "أشهر وأشعل معركة باتل رويال في العالم الآن مفتوحة للجميع مجانًا"
  },
  {
    id: "val-m",
    title: "Valorant",
    genre: "تصويب تكتيكي / تنافسي",
    rating: 4.9,
    image: "https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&q=80&w=600",
    platform: "Riot Games",
    description: "لعبة إطلاق نار تكتيكية حادة تتطلب دقة متناهية وعمل تكتيكي استراتيجي"
  },
  {
    id: "fort-m",
    title: "Fortnite",
    genre: "بناء / باتل رويال",
    rating: 4.7,
    image: "https://images.unsplash.com/photo-1553481187-be93c21490a9?auto=format&fit=crop&q=80&w=600",
    platform: "Epic Games",
    description: "اهبط وابنِ وحارب حتى النصر في صالة ألعاب الباتل رويال الشائعة مجاناً"
  },
  {
    id: "gensh-m",
    title: "Genshin Impact",
    genre: "تقمص أدوار / عالم مفتوح",
    rating: 4.9,
    image: "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?auto=format&fit=crop&q=80&w=600",
    platform: "HoYoverse",
    description: "استكشف عالم تيفات الشاسع واجمع الشخصيات وقاتل الوحوش بقدرات العناصر الخيالية"
  }
];

export default function TrendingGames() {
  return (
    <section className="py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10" id="trending-section">
      <div className="text-center md:text-right mb-12">
        <h2 className="text-2xl sm:text-3xl font-extrabold font-[Changa] text-transparent bg-clip-text bg-gradient-to-l from-white to-slate-200 flex items-center justify-center md:justify-start gap-2">
          <span>📈 الألعاب الرائجة والمفضّلة</span>
        </h2>
        <p className="text-slate-400 text-xs sm:text-sm font-[Tajawal] mt-1">
          أكثر الألعاب المجانية نشاطاً والّتي يقبل عليها اللاعبون العرب هذا الأسبوع
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {TRENDING_MOCK.map((game) => (
          <div
            key={game.id}
            className="group relative glass-card border border-slate-800/80 hover:border-cyan-500/30 rounded-2xl overflow-hidden transition-all duration-300 hover:-translate-y-1.5 hover:shadow-[0_10px_30px_rgba(34,211,238,0.1)] flex flex-col justify-between"
          >
            {/* Soft inner color hover bleed */}
            <div className="absolute inset-0 bg-cyan-500/0 group-hover:bg-cyan-500/5 transition duration-300 pointer-events-none"></div>

            <div>
              {/* Card visual banner */}
              <div className="aspect-video w-full relative bg-slate-950 overflow-hidden">
                <img
                  src={game.image}
                  alt={game.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <span className="absolute top-3 right-3 text-[10px] font-bold px-2 py-1 rounded bg-black/80 backdrop-blur-md text-cyan-400 border border-cyan-500/20">
                  {game.platform}
                </span>
                <span className="absolute bottom-3 left-3 text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/25 backdrop-blur text-emerald-400 border border-emerald-500/20">
                  فريق اللعب
                </span>
              </div>

              {/* Card Content details */}
              <div className="p-5 select-none">
                <div className="text-[10px] font-semibold text-cyan-400 font-[Cairo] mb-1">
                  {game.genre}
                </div>
                <h3 className="text-base font-bold text-white group-hover:text-cyan-300 transition duration-200 font-[Cairo]">
                  {game.title}
                </h3>
                <p className="text-slate-400 text-xs leading-relaxed mt-2 line-clamp-2 font-[Tajawal]">
                  {game.description}
                </p>
              </div>
            </div>

            {/* Rating card footer action */}
            <div className="p-5 pt-0 border-t border-slate-900/40 flex justify-between items-center mt-4">
              <div className="flex items-center gap-1">
                <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                <span className="text-xs font-bold text-slate-300 font-[Cairo]">{game.rating}</span>
              </div>
              <span className="text-xs font-bold text-cyan-400 underline group-hover:text-white transition cursor-pointer">
                العب الآن مجاناً ◀
              </span>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
