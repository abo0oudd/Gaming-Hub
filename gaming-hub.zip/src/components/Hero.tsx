/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from "react";
import { Gamepad2, Users, ArrowUpRight, Zap, Cpu } from "lucide-react";
import { motion } from "motion/react";

interface HeroProps {
  setCurrentPage: (page: string) => void;
}

export default function Hero({ setCurrentPage }: HeroProps) {
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePos({
        x: (e.clientX / window.innerWidth) * 40 - 20,
        y: (e.clientY / window.innerHeight) * 40 - 20,
      });
    };
    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, []);

  return (
    <section className="relative min-h-screen flex items-center justify-center pt-24 pb-16 overflow-hidden bg-transparent px-4 sm:px-6 lg:px-8">
      {/* Cinematic grid overlay */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(99,102,241,0.03)_1px,transparent_1px),linear-gradient(to_bottom,rgba(99,102,241,0.03)_1px,transparent_1px)] bg-[size:4rem_4rem]"></div>
      <div className="absolute inset-0 bg-gradient-to-t from-[#020205] via-transparent to-[#020205]"></div>

      {/* Cyber ambient glows */}
      <div className="absolute top-1/4 left-1/4 w-[35rem] h-[35rem] bg-indigo-500/[0.04] rounded-full blur-[120px] mix-blend-screen pointer-events-none"></div>
      <div className="absolute bottom-1/4 right-1/4 w-[25rem] h-[25rem] bg-purple-500/[0.04] rounded-full blur-[100px] mix-blend-screen pointer-events-none"></div>

      <div className="max-w-5xl mx-auto text-center relative z-10 flex flex-col items-center">
        {/* Hub Badge */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-xs font-bold text-indigo-300 mb-6 font-[Cairo]"
        >
          <span className="w-1.5 h-1.5 rounded-full bg-purple-400 animate-ping"></span>
          <span>منصّة الألعاب العربيّة السحابيّة الأولى</span>
        </motion.div>

        {/* Headline */}
        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight font-[Changa] text-transparent bg-clip-text bg-gradient-to-b from-white to-slate-400 leading-tight mb-6"
        >
          اكتشف وبادر بامتلاك <br className="hidden sm:inline" />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-indigo-400 to-cyan-400 font-black animate-pulse">
            أقوى الألعاب المجانيّة!
          </span>
        </motion.h1>

        {/* Sub-headline */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="text-base sm:text-lg lg:text-xl text-slate-400 max-w-3xl leading-relaxed mb-10 font-[Tajawal]"
        >
          احصل على الألعاب المدفوعة والممتازة مجاناً بالكامل من أشهر المتاجر العالمية، ولّد ميمز أسطورية، واستكشف حسابات ستيم مجانية ممتازة ومفتوحة للجميع وسيرفر ماين كرافت حماسي مشوق!
        </motion.p>

        {/* Actions buttons and indicators */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="flex flex-col sm:flex-row gap-4 items-center justify-center mb-16 w-full max-w-md"
        >
          <button
            onClick={() => setCurrentPage("gamemind-nexus")}
            className="w-full sm:w-auto relative group inline-flex items-center justify-center gap-2 py-4 px-8 rounded-2xl font-bold text-sm text-white bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 shadow-lg hover:shadow-purple-500/10 shadow-indigo-500/10 transition duration-300"
          >
            <span>دخول مُختبر الذكاء الاصطناعي</span>
            <Gamepad2 className="w-5 h-5 text-purple-200 group-hover:rotate-12 transition-transform" />
          </button>

          <button
            onClick={() => setCurrentPage("mcservercleanpro")}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 py-4 px-8 rounded-2xl font-bold text-sm text-slate-300 hover:text-white bg-[#04040a]/80 border border-slate-900 hover:border-purple-500/20 transition duration-200"
          >
            <span>خوض مغامرة ماين كرافت</span>
            <Users className="w-5 h-5 text-slate-400" />
          </button>
        </motion.div>

        {/* Decorative Floating Components (Using simulated parallax movement from cursor coords) */}
        <div
          className="hidden lg:block absolute inset-0 pointer-events-none"
          style={{
            transform: `translate(${mousePos.x}px, ${mousePos.y}px)`,
            transition: "transform 0.1s linear",
          }}
        >
          <div className="absolute top-1/4 right-[5%] w-16 h-16 bg-gradient-to-br from-indigo-500 to-cyan-500/20 text-indigo-400 flex items-center justify-center rounded-2xl shadow-lg border border-white/10 animate-[bounce_4s_infinite]">
            <Gamepad2 className="w-6 h-6 animate-pulse" />
          </div>
          <div className="absolute bottom-1/3 left-[5%] w-14 h-14 bg-gradient-to-tr from-purple-500 to-pink-500/20 text-purple-400 flex items-center justify-center rounded-xl shadow-lg border border-white/10 animate-[bounce_5s_infinite]">
            <Zap className="w-5 h-5" />
          </div>
          <div className="absolute top-[60%] right-[10%] w-12 h-12 bg-slate-900/80 border border-slate-800 text-slate-400 flex items-center justify-center rounded-lg shadow animate-[pulse_3s_infinite]">
            <Cpu className="w-4 h-4" />
          </div>
        </div>
      </div>
    </section>
  );
}
