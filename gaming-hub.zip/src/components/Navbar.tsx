/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { Menu, X, Bell, Search, Gamepad2, Info, Mail } from "lucide-react";

interface NavbarProps {
  currentPage: string;
  setCurrentPage: (page: string) => void;
}

export default function Navbar({ currentPage, setCurrentPage }: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navItems = [
    { id: "home", label: "الرئيسية" },
    { id: "gamemind-nexus", label: "عقل اللاعب" },
    { id: "steam-accounts", label: "حسابات ستيم" },
    { id: "mcservercleanpro", label: "سيرفر ماين كرافت" },
  ];

  return (
    <nav
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 ${
        isScrolled
          ? "bg-slate-950/80 backdrop-blur-md border-b border-indigo-500/10 py-3 shadow-[0_4px_30px_rgba(0,0,0,0.5)]"
          : "bg-transparent py-5"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-12">
          {/* Logo */}
          <div className="flex-shrink-0 flex items-center">
            <button
              onClick={() => setCurrentPage("home")}
              className="flex items-center gap-2 font-bold text-xl select-none"
            >
              <Gamepad2 className="w-6 h-6 text-purple-400 stroke-[2px]" />
              <span className="text-white font-[Changa] tracking-tight hover:text-indigo-400 transition-colors">
                Gaming<span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-cyan-400">Hub</span>
              </span>
            </button>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:block">
            <div className="flex items-center gap-1">
              {navItems.map((item) => {
                const isActive = currentPage === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setCurrentPage(item.id);
                      setIsOpen(false);
                    }}
                    className={`nav-link text-sm font-semibold px-4 py-2 rounded-xl transition duration-200 relative ${
                      isActive
                        ? "text-purple-400 bg-purple-500/10 border border-purple-500/20 shadow-[0_0_15px_rgba(168,85,247,0.1)]"
                        : "text-slate-300 hover:text-indigo-300"
                    }`}
                  >
                    {item.label}
                    {isActive && (
                      <span className="absolute bottom-0 inset-x-6 h-[2px] bg-gradient-to-r from-purple-400 to-cyan-400 rounded-full blur-[1px]"></span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* User Interaction Icons */}
          <div className="flex items-center gap-2">
            {/* Mobile Hamburger toggle */}
            <div className="md:hidden flex items-center ms-2">
              <button
                onClick={() => setIsOpen(!isOpen)}
                className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-900 border border-transparent hover:border-slate-800 transition focus:outline-none"
              >
                {isOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Drawer (Smooth slide) */}
      {isOpen && (
        <div className="md:hidden bg-slate-950/95 backdrop-blur-lg border-b border-indigo-500/10 absolute top-full inset-x-0 transition-all duration-300 py-4 px-6 space-y-2">
          {navItems.map((item) => {
            const isActive = currentPage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setCurrentPage(item.id);
                  setIsOpen(false);
                }}
                className={`w-full text-right block px-4 py-3 rounded-xl text-sm font-bold transition ${
                  isActive
                    ? "text-purple-400 bg-purple-500/10 border border-purple-500/20"
                    : "text-slate-300 hover:text-indigo-300"
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </div>
      )}
    </nav>
  );
}
