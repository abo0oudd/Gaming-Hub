/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import StatsSection from "./components/StatsSection";
import GameMindNexus from "./components/GameMindNexus";
import SteamAccountsPage from "./components/SteamAccountsPage";
import MCServerPage from "./components/MCServerPage";
import { Game, SteamAccount, Post } from "./types";
import { Sparkles, Gamepad2, Target, Lock, Cpu, Heart, Gift, Zap, MessageSquare } from "lucide-react";

export default function App() {
  const [currentPage, setCurrentPage] = useState<string>("home");

  // State data store
  const [games, setGames] = useState<Game[]>([]);
  const [steamAccounts, setSteamAccounts] = useState<SteamAccount[]>([]);
  const [posts, setPosts] = useState<Post[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    loadAllData();
  }, []);

  const loadAllData = async () => {
    try {
      setIsLoading(true);

      const [gamesRes, accountsRes, postsRes] = await Promise.all([
        fetch("/api/games"),
        fetch("/api/steam-accounts"),
        fetch("/api/posts"),
      ]);

      if (gamesRes.ok && accountsRes.ok && postsRes.ok) {
        const gamesData = await gamesRes.json();
        const accountsData = await accountsRes.json();
        const postsData = await postsRes.json();

        setGames(gamesData);
        setSteamAccounts(accountsData);
        setPosts(postsData);
      }
    } catch (e) {
      console.error("Failed to fetch full state", e);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#020205] bg-gradient-to-b from-[#020205] via-[#050614] to-[#010103] text-white flex flex-col font-sans select-none overflow-x-hidden antialiased relative">
      {/* Cinematic Ambient Glow */}
      <div className="absolute top-0 right-1/4 w-[50rem] h-[35rem] bg-indigo-500/[0.03] rounded-full blur-[160px] pointer-events-none z-0"></div>
      <div className="absolute top-[30rem] left-1/4 w-[40rem] h-[30rem] bg-purple-500/[0.02] rounded-full blur-[180px] pointer-events-none z-0"></div>

      <Navbar
        currentPage={currentPage}
        setCurrentPage={setCurrentPage}
      />

      {/* Main Content Layout routing panel */}
      <main className="flex-grow pt-16 relative z-10 w-full">
        {isLoading ? (
          <div className="min-h-[70vh] flex flex-col items-center justify-center gap-4">
            <div className="w-10 h-10 border-4 border-purple-500/10 border-t-purple-500 rounded-full animate-spin"></div>
            <p className="text-slate-400 text-xs font-[Cairo] flex items-center gap-1.5 animate-pulse">
              <Zap className="w-3.5 h-3.5 text-purple-400 animate-pulse" />
              <span>جاري تحميل منصّة Gaming Hub...</span>
            </p>
          </div>
        ) : (
          <>
            {currentPage === "home" && (
              <div className="space-y-12">
                <Hero setCurrentPage={setCurrentPage} />

                {/* DISCORD COMMUNITTY PREMIUM CARD WIDGET */}
                <section className="max-w-4xl mx-auto px-4 relative z-10" id="discord-guild-hub">
                  <div className="bg-[#04040a]/80 backdrop-blur-xl rounded-3xl p-6 sm:p-10 border border-purple-500/15 hover:border-purple-500/35 transition-all duration-500 shadow-[0_0_40px_rgba(147,51,234,0.08)] text-center relative overflow-hidden group">
                    {/* Decorative ambient flare in the card */}
                    <div className="absolute -top-12 -right-12 w-40 h-40 bg-purple-600/10 rounded-full blur-2xl group-hover:scale-125 transition-transform duration-700"></div>
                    <div className="absolute -bottom-12 -left-12 w-40 h-40 bg-blue-600/10 rounded-full blur-2xl group-hover:scale-125 transition-transform duration-700"></div>

                    <div className="relative z-10 space-y-6">
                      <div className="inline-flex py-1.5 px-3 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-semibold tracking-wide">
                        سيرفر الديسكورد الرسمي للمنصّة
                      </div>

                      {/* Giant Discord Style Icon with custom CSS SVG representation */}
                      <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-indigo-600 to-purple-600 flex items-center justify-center mx-auto shadow-lg shadow-indigo-600/20 group-hover:scale-105 transition-transform duration-300">
                        <svg className="w-9 h-9 text-white" fill="currentColor" viewBox="0 0 127.14 96.36">
                          <path d="M107.7,8.07A105.15,105.15,0,0,0,77.26,0a77.19,77.19,0,0,0-3.3,6.83A96.67,96.67,0,0,0,53.22,6.83,77.19,77.19,0,0,0,49.88,0,105.15,105.15,0,0,0,19.44,8.07C3.66,31.58-1.86,54.65,1,77.53A105.73,105.73,0,0,0,32,96.36a77.7,77.7,0,0,0,6.63-10.85,68.43,68.43,0,0,1-10.5-5c.88-.65,1.72-1.34,2.51-2.07a75.14,75.14,0,0,0,73.1,0c.8, balance, .79,1.42,2.51,2.07a68.43,68.43,0,0,1-10.5,5,77.7,77.7,0,0,0,6.63,10.85,105.73,105.73,0,0,0,31-18.83C129,54.65,123.48,31.58,107.7,8.07ZM42.45,65.69C36.18,65.69,31,60,31,53S36.18,40.36,42.45,40.36,53.9,46,53.9,53,48.72,65.69,42.45,65.69Zm42.24,0C78.41,65.69,73.24,60,73.24,53S78.41,40.36,84.69,40.36,96.14,46,96.14,53,91,65.69,84.69,65.69Z" />
                        </svg>
                      </div>

                      <div className="space-y-2">
                        <h2 className="text-xl sm:text-2xl font-black font-[Changa] text-white">انضم إلى مجتمعنا الأسطوري في الديسكورد</h2>
                        <span className="block h-[2px] w-12 bg-purple-500 mx-auto rounded-full"></span>
                      </div>

                      <p className="text-slate-400 text-xs sm:text-sm font-[Tajawal] max-w-xl mx-auto leading-relaxed">
                        تواصل مع آلاف اللاعبين، شارك في بطولات السيرفر الأسبوعية، واحصل على دعم فني فوري وخاص لسيرفر ماين كرافت وفعاليات مشتركة لا تنتهي.
                      </p>

                      <div className="pt-2">
                        <a
                          href="https://discord.gg/ydWZQkGZ3M"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-2 py-3.5 px-10 rounded-2xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-bold text-sm tracking-wide shadow-lg shadow-indigo-500/10 hover:shadow-indigo-500/25 border border-indigo-500/15 transform hover:-translate-y-0.5 transition-all duration-300"
                        >
                          <MessageSquare className="w-4 h-4 stroke-[2.5px]" />
                          <span>دخول المجتمع والدعم الفني المباشر</span>
                        </a>
                      </div>
                    </div>
                  </div>
                </section>

                <StatsSection />

                {/* About and footers of home page */}
                <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 bg-gradient-to-t from-[#020205] to-transparent relative z-10" id="about-section">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    <div className="bg-[#04040a]/40 backdrop-blur-md p-6 border border-slate-900/60 rounded-3xl text-right hover:border-purple-500/10 transition-all">
                      <div className="w-10 h-10 rounded-xl bg-purple-500/10 flex items-center justify-center text-purple-400 mb-4">
                        <Target className="w-5 h-5" />
                      </div>
                      <h4 className="text-base font-bold text-white mb-2 font-[Cairo]">هدف المنصة الأسمى</h4>
                      <p className="text-slate-400 text-xs leading-relaxed font-[Tajawal]">
                        توفير الألعاب المدفوعة والممتازة مجاناً بالكامل من المتاجر الكبرى لجمع اللاعبين العرب وبناء مجتمع راقٍ ونابض بالحياة.
                      </p>
                    </div>

                    <div className="bg-[#04040a]/40 backdrop-blur-md p-6 border border-slate-900/60 rounded-3xl text-right hover:border-cyan-500/10 transition-all">
                      <div className="w-10 h-10 rounded-xl bg-cyan-500/10 flex items-center justify-center text-cyan-400 mb-4">
                        <Lock className="w-5 h-5" />
                      </div>
                      <h4 className="text-base font-bold text-white mb-2 font-[Cairo]">أمان مشترك وجدارة</h4>
                      <p className="text-slate-400 text-xs leading-relaxed font-[Tajawal]">
                        حسابات ستيم المقدمة عامة ومشتركة بصورة آمنة وموثوقة، خاضعة للمراقبة بشكل كامل لضمان استمراريتها ومساعدة الجميع.
                      </p>
                    </div>

                    <div className="bg-[#04040a]/40 backdrop-blur-md p-6 border border-slate-900/60 rounded-3xl text-right hover:border-indigo-500/10 transition-all">
                      <div className="w-10 h-10 rounded-xl bg-indigo-500/10 flex items-center justify-center text-indigo-400 mb-4">
                        <Cpu className="w-5 h-5 animate-pulse" />
                      </div>
                      <h4 className="text-base font-bold text-white mb-2 font-[Cairo]">ذكاء الميمز التوليدي</h4>
                      <p className="text-slate-400 text-xs leading-relaxed font-[Tajawal]">
                        محرك مولد الميمز الرهيب يدمج أحدث نماذج رؤية الذكاء الاصطناعي مع Gemini 3.5 Flash للحصول على أطرف المقترحات في ثوانٍ.
                      </p>
                    </div>
                  </div>
                </section>
              </div>
            )}

            {currentPage === "gamemind-nexus" && (
              <GameMindNexus games={games} />
            )}

            {currentPage === "steam-accounts" && (
              <SteamAccountsPage accounts={steamAccounts} />
            )}

            {currentPage === "mcservercleanpro" && (
              <MCServerPage />
            )}
          </>
        )}
      </main>

      {/* FOOTER */}
      <footer className="bg-[#030307]/90 backdrop-blur-md border-t border-slate-900 py-12 relative z-10 select-none">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-4 gap-8 text-right">
          <div className="space-y-4">
            <h3 className="text-lg font-black text-transparent bg-clip-text bg-gradient-to-l from-white to-slate-200 flex items-center justify-end gap-1.5">
              <span>Gaming</span><span className="text-purple-400 font-black">Hub</span>
            </h3>
            <p className="text-slate-400 text-xs font-[Tajawal] leading-relaxed">
              منصة الترفيه ومستودع عروض الألعاب العربية الأولى. بوابتك لجمع الغنائم والميمات والتحدي الأسطوري بالمحافل الدولية!
            </p>
          </div>

          <div>
            <h4 className="text-sm font-bold text-white mb-4 font-[Cairo]">روابط سريعة</h4>
            <ul className="space-y-2 text-xs text-slate-400 font-[Tajawal]">
              <li><button onClick={() => setCurrentPage("home")} className="hover:text-purple-400 transition">الرئيسية</button></li>
              <li><button onClick={() => setCurrentPage("gamemind-nexus")} className="hover:text-purple-400 transition">عقل اللاعب</button></li>
              <li><button onClick={() => setCurrentPage("steam-accounts")} className="hover:text-purple-400 transition">حسابات ستيم</button></li>
              <li><button onClick={() => setCurrentPage("mcservercleanpro")} className="hover:text-purple-400 transition">سيرفر ماين كرافت</button></li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-bold text-white mb-4 font-[Cairo]">الأمان والتعاون</h4>
            <p className="text-slate-400 text-xs font-[Tajawal] leading-relaxed">
              إن كافة بيانات حسابات تداول ستيم المشتركة يتم تثبيتها وحمايتها برمجياً لمنع محاولات تغيير الكلمة العشوائية. نرجو الدخول واللعب أوفلاين.
            </p>
          </div>

          <div className="space-y-4">
            <h4 className="text-sm font-bold text-white font-[Cairo]">النشرة البريدية</h4>
            <p className="text-slate-500 text-[10px] font-[Tajawal]">اشترك لتلقي تنبيهات عند نزول عروض ألعاب Epic Games مجاناً ومباشرة.</p>
            <div className="flex bg-[#07070f] rounded-xl p-1 border border-slate-900">
              <input
                type="email"
                placeholder="بريدك الإلكتروني..."
                className="bg-transparent text-xs text-white px-3 focus:outline-none w-full text-right"
              />
              <button className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-xs text-white font-bold rounded-lg transition leading-5">
                اشتراك
              </button>
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 mt-8 border-t border-slate-900/60 text-center text-[10px] text-slate-500 font-[Tajawal] flex items-center justify-center gap-1">
          <span>© 2026 Gaming Hub. جميع الحقوق محفوظة لرواد اللعب العربي. تم التطوير بذكاء و</span>
          <Heart className="w-3 h-3 text-red-500 fill-red-500 animate-pulse" />
        </div>
      </footer>
    </div>
  );
}
